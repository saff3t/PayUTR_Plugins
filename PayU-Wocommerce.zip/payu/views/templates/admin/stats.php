<?php echo $last_records->display(); ?>
	<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<div class="row panel" style="min-height:400px">
	<div class="col-sm-6">
		<?php echo $stats_monthly ?>
	</div>
	<div class="col-sm-6">
		<?php echo $stats_gateways ?>
	</div>
</div>