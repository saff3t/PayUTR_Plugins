<link rel='stylesheet' href='<?php echo plugins_url('/payu/views/css/admin.css') ?>' type='text/css' media='all' />

<div class="spp_bootstrap-wrapper">
	<div class="panel" style="padding:45px">
		<?php if (isset($error_message)): ?>
			<div class="alert alert-danger">
				Kayıt sırasında hata oluştu.
				<?php echo $error_message ?>
			</div>
		<?php endif; ?>
		<fieldset>
			<h2	align="center">Kurulum veya Güncelleme Yapmak Üzeresiniz!</h2>
			<hr/>
			<div class="row">
				<h3>PayU SanalPos Nedir ?</h3>
				<ul>
                  <li>PayU SanalPos, Eticaret sitenizden kredi kartı ile ödeme almanızı sağlayan, SanalPOS yazılımıdır.</li>
                  <li>PayU SanalPos, açık kaynak olarak geliştirilmiş bir modüldür. Kaynak dosyalarında tarafınızca gerçekleştirilmiş değişikliklerden oluşacak problemlerden PayU ve Eticsoft firmaları sorumlu değildir.</li>
                  <li>Modülü kurulumu ve detaylı bilgi için lütfen <a href="../wp-content/plugins/payu/readme.md" target="_blank">tıklayınız</a>.</li>
               </ul>
			</div>
			<hr/>
			<div class="row">
				<h2>Kullanmaya Başlamak İçin Aşağıdaki Formu Doldurunuz.</h2>
				<small>Bu formdaki bilgilerle Payu hesabınız kurulacak (veya güncellenecek) 
					girdiğiniz bilgiler tamamen gizli tutulacak, 3. kişi ve/veya kurumlarla paylaşılmayacaktır.
					Formu doldurduğunuzda mağazanızın URL adresi ve yazılımınızın versionu da kayıt edilecek,
					bu bilgiler ileride ücretsiz güncelleme ve güvenlik kontrolü v.b. işlemlerinde kullanılacaktır.
				</small>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="input-group">
						<label>Adınız</label><br/>
						<input type="text" name="spr_shop_firstname" class="form-control" required/>
					</div>
					<div class="input-group">
						<label>Soyadınız</label><br/>
						<input type="text" name="spr_shop_lastname" class="form-control" required />
					</div>
				</div>
				<div class="col-md-6">
					<div class="input-group">
						<label class="label label-danger"> Cep Telefonu Numaranız </label><br/>
						<input class="form-control" name="spr_shop_phone" type="tel" pattern="^[0-9\-\+\s\(\)]*$" maxlength="11" minlength="11" placeholder="05XX XXX XXXX" required />
					</div>
					<div class="input-group">
						<label>Bir Şifre Belirleyin</label><br/>
						<input class="form-control" type="text" name="spr_shop_password" required/>
					</div>
				</div>
			</div>
			<br/>
			<div class="alert alert-info"><b>Bu bilgiler hiçbir kişi veya kurum ile paylaşılmayacak olup</b> istenildiği 
				taktirde kullanıcı tarafından silinebilecektir. 
				Telefon numaranız ve e-postanız dolandırıcılık koruma işlemleri, değişiklikler ve güncellemeler 
				ile ilgili bilgilendirme amaçlı kullanılılacak olup isteğiniz dışında
				<strong>hiç bir şekilde reklam/tanıtım amaçlı kullanılmayacaktır.</strong></div>
			<div class="checkbox-inline">
				<input type="checkbox" checked="true" required name="tos_payu"/> 
				PayU! <a href="https://www.payu.com.tr/calisma-kosullari" target="_blank">Kullanım Koşullarını</a> Okudum Kabul Ediyorum
			</div>
			<br/>
			<div class="checkbox-inline">
				<input type="checkbox" checked="true" class="" name="tos_payu"/> 
				FP007 Dolandırıcılık Koruma Servisi (Ücretsiz) <a href="https://www.payu.com.tr/kisisel-verilerin-korunmasi" target="_blank">Kullanım Koşullarını </a>Okudum Kabul Ediyorum
			</div>
		</fieldset>
		<div class="row text-center align-center">
			<br/>
			<input type="hidden" name="spr_terms" value="1"/>
			<input type="hidden" name="spr_shop_key" value=""/>
			<button type="submit" class="center btn btn-large btn-info">Kurulumu Tamamla</button>
		</div>
	</div>
</div>
