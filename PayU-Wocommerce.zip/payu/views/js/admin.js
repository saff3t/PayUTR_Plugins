(function () {
    var startingTime = new Date().getTime();
    // Load the script
    var script = document.createElement("SCRIPT");
    script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js';
    script.type = 'text/javascript';
    document.getElementsByTagName("head")[0].appendChild(script);

    // Poll for jQuery to come into existance
    var checkReady = function (callback) {
        if (window.jQuery) {
            callback(jQuery);
        } else {
            window.setTimeout(function () {
                checkReady(callback);
            }, 20);
        }
    };

    // Start polling...
    checkReady(function (jQuery) {
        jQuery(function () {
            var endingTime = new Date().getTime();
            var tookTime = endingTime - startingTime;
            console.log("jQuery is loaded, after " + tookTime + " milliseconds!");
        });
    });
})();


jQuery('ul.nav-tabs li a').click(function (e) {
    jQuery('ul.nav-tabs li.active').removeClass('active')
    jQuery(this).parent('li').addClass('active')
})

var $ = jQuery;

$(document).ready(function () {
    $("select.inst_select").change(function () {
        var cname = $(this).attr("id");
        if ($(this).val() == 0)
            $("." + cname).hide();
        else
            $("." + cname).show();
    });

    $("select.inst_select_all").change(function () {
        var cnameall = $(this).attr("id");
        if ($(this).val() == 0) {
            $("select." + cnameall).val(0);
            $("input.input_" + cnameall).hide();
        } else {
            $("select." + cnameall).val($(this).val());
            $("input.input_" + cnameall).show()
        }
    });
    $("select.inst_select").change();
});

