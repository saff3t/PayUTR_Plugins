<?php


		require_once(dirname(__FILE__) . '/../../../wp-config.php');
		require_once(dirname(__FILE__) . '/lib/class/inc.php');
		require_once(dirname(__FILE__) . '/lib/class/EticPayuIpn.php');
		
		$ipn = new EticPayuIpn();
		$tr = (array)$ipn->run();
		
		
		
		if(!$tr OR !$tr['id_order'] OR $tr['result'] == false)
			 die("invalid transaction");

		$order = new WC_Order($tr['id_order']);
		
		if	(EticTools::getValue('ORDERSTATUS') == 'COMPLETE' OR EticTools::getValue('ORDERSTATUS') == 'PAYMENT_AUTHORIZED'){
			$order->update_status('processing', __(EticTools::getValue('ORDERSTATUS'), 'woocommerce'));
		}
		
		$order->add_order_note('PayU IPN ile geri şu geri bildirimi yaptı: '.EticTools::getValue('ORDERSTATUS').' İşlem no: #' . $tr->id_transaction);
