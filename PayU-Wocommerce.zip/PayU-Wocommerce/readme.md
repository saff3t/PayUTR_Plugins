=== Plugin Name ===
Tags: woocommerce, kredi karti, sanalpos, PayU
Contributors: EticSoft R&D Lab Teknokent Akdeniz Ünv.
Requires at least: 3.6.4
Tested up to: 3.6.4
Stable tag: 3.6.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Credit Card Payment GateWay for PayU merchants (Turkey/Türkiye only) / PayU ile kredi karti ödeme eklentisi

# Wordpress WooCommerce PayU SanalPOS Modülü 

Powered by [EticSoft](https://eticsoft.com) - EticSoft R&D Lab.

> Bu eklenti PayU Ödeme Kurulusu A.S. ile EticSoft arasindaki isbirligine istinaden EticSoft tarafindan gelistirilmistir. 

> Bu eklenti Wordpress 5.0x ve WooCommerce 3.0.0x ve üzeri versiyonlar ile tam uyumludur. WP 4.0 ve Woo 3.0 altindaki versiyonlarda test edilmemistir. 

PayU SanalPOS Modülü Wordpress WooCommerce e-ticaret sisteminize PayU sanalPOS entegrasyonunu saglar. Bu eklenti ile müsterileirniz magazanizdan kredi kartlari ile alisveris yapabilirler. 

  - Tamamen ücretsizdir ve açik kaynak kodludur.
  - Hiç bir kod modifikasyonu istemez. Kurulum ve kaldirma islemleri basittir.
  - Tüm kredi kartlarindan ödeme alir.
  - Ödemenin güvenli ve kolay olmasini saglar
  - Hiç bir teknik bilgi istemeden kolayca kurulur ve kaldirilir. 

# Kullanim Sartlari

  - PayU modülü PayU Ödeme Kurulusu A.S tarafindan GPL lisansi ile açik kaynakli ve ücretsiz sunulmaktadir. Satilamaz.
  - PayU modülü PayU Ödeme Kurulusu A.S 'nin sagladigi servisleri kullanmak için gelistirilmistir. Baska amaçla kullanilamaz.
  - Uluslararasi kabul görmüs güvenlik standartlarina göre ödeme yapilan kredi karti bilgilerine erisilmesi veya bilgilerin kayit edilmesi yasaktir. Bu eklenti orijinal kaynak kodlariyla müsterilerinizin kredi karti bilgilerini siteminize veya herhangi bir yere asla kaydetmez. Kaynak kodlarini bu kurallara uygun tutmak sizin sorumlulugunuzdadir.
  - Eklentinin kurulu olacagi magazaya ait version ve iletisim bilgileriniz (magaza eposta, Wordpress WooCommerce versiyonu v.b.) gelistirici teknik destek ve bilgilendirme sistemine otomatik kayit edilecek ve bu bilgiler önemli bildirimler ile güncellemelerden haberdar olmaniz için kullanilacaktir.


# Kurulum 
  - Wordpress WooCommerce yönetim panelinize giris yapin. Eklentiler sekmesine girin.
  - Yeni eklenti yüklemeyi seçip indirdiginiz zip dosyasini yükleyin.
  - Yükleme bittikten sonra Woocommerce -> Settings -> Payment bölümünden eklentinin ayarlarina girip seçenekleri düzenleyin.
  - Magazanizin ön sayfasina giris yapip EN AZ BIR BASARILI ÖDEME YAPMAYI DENEYIN !

# Yardim 

* [PayU web](https://payu.com.tr) - PayU Ödeme Kurulusu A.S.
* [EticSoft web](https://eticsoft.com) - EticSoft R&D Lab.
* [EticSoft destek sistemi](https://eticsoft.com/support) - EticSoft R&D Lab.
* [Eklentiler](https://eticsoft.com/shop) - EticSoft Shop.
