<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
</form>
<link rel='stylesheet' href='<?php echo plugins_url('/payu/views/css/admin.css') ?>' type='text/css' media='all' />

<div class="spp_bootstrap-wrapper">
	<hr/>
	<div class="row panel">
		<div class="col-sm-4 col-xs-4">
			<a target="_blank;" href="https://www.payu.com.tr/">
				<img src="<?php echo plugins_url() ?>/payu/img/logo.png" /> 
			</a>
		</div>
				<div class="col-sm-4 col-xs-4 text-center">
			<span style="font-size:3.5em;">v<?php echo ((float) $this->version ) ?></span>
					
		</div>
		<div class="col-sm-4 col-xs-4 text-right">
			
		</div>
	</div>
	<div class="row">

		<?php if ($messages): ?>
			<?php foreach ($messages as $mesg): ?>
				<div class="col-sm-6 col-xs-12">
					<div class="alert alert-<?php echo $mesg['type'] ?>"><?php echo $mesg['message'] ?></div>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>

	</div>
	<?php if ($viewlog): ?>
		<div class="row">
			<div class="col-sm-12 col-xs-12">
				İşlem İçin Kayıt Defteri
				<pre><textarea style="height: 300px"><?php echo $viewlog ?></textarea></pre>
														</div>
													</div>
	<?php endif; ?>

	<!-- Nav tabs -->
	<ul class="nav nav-tabs" role="tablist">
		<li class="active"><a href="#payusettings" role="tab" data-toggle="tab"><i class="icon icon-cogs"></i> Genel Ayarlar</a></li>
		<li><a href="#pos" role="tab" data-toggle="tab"><i class="icon icon-cart-arrow-down"></i>POS Ayarları</a></li>
		<li><a href="#cards" role="tab" data-toggle="tab"><i class="icon icon-credit-card"></i> Taksitler </a></li>
		<!-- <li><a href="#integration" role="tab" data-toggle="tab"><i class="icon icon-link"></i> Yöntem Ekle </a></li> -->
		<li><a href="#help" role="tab" data-toggle="tab"><i class="icon icon-question"></i> Destek</a></li>
		<!-- <li><a href="#stats" role="tab" data-toggle="tab"><i class="icon icon-list"></i> İşlemler</a></li>
		<li><a href="#tools" role="tab" data-toggle="tab"><i class="icon icon-keyboard"></i> Araçlar</a></li>
		<li><a href="#masterpass" role="tab" data-toggle="tab"><img class="" src="<?php echo plugins_url() ?>/payu/img/masterpass.svg" style="width: 125px;"></a></li> -->
	</ul>

	<!-- Tab panes -->
	<div class="tab-content">
		<div class="tab-pane active" id="payusettings"><?php echo $general_tab ?></div>
		<div class="tab-pane" id="pos"><?php echo $banks_tab ?></div>
		<div class="tab-pane" id="cards"><?php echo $cards_tab ?></div>
		<div class="tab-pane" id="integration"><?php echo $integration_tab ?></div>
		<div class="tab-pane" id="help"> <?php echo $help_tab ?> </div>
		<div class="tab-pane" id="stats"><?php echo include(dirname(__FILE__) . '/stats.php') ?></div>
		<div class="tab-pane" id="tools"><?php echo $tools_tab ?></div>
		<div class="tab-pane" id="masterpass"><?php echo $masterpass_tab ?></div>
	</div>
	
	<div class="panel">
		<div class="panel-header">
			<h2> EticSoft R&D Lab Teknokent Akdeniz Ünv. </h2>
		</div>
		<div class="panel-body">
			<div class="row eticsoft_garantipay-header">
				<div class="col-xs-6 col-md-4 text-center">
					<iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FEticSoft%2F&width=450&layout=standard&action=like&size=small&show_faces=true&share=true&height=80&appId=166162726739815" width="450" height="80" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>		</div>
				<div class="col-xs-6 col-md-8 text-center">
					<a href="https://www.youtube.com/user/EticSoft"><img src="<?php echo plugins_url() ?>/payu/img/icons/youtube.png" target="_blank" /></a>
					<a href="https://www.linkedin.com/company/eticsoft-yaz%C4%B1l%C4%B1m"><img src="<?php echo plugins_url() ?>/payu/img/icons/linkedin.png" target="_blank" /></a>
					<a href="https://twitter.com/eticsoft"><img src="<?php echo plugins_url() ?>/payu/img/icons/twitter.png" target="_blank" /></a>
					<a href="https://www.instagram.com/eticsoft/"><img src="<?php echo plugins_url() ?>/payu/img/icons/instagram.png" target="_blank" /></a>
					<a href="https://wordpress.org/support/users/eticsoft-lab/"><img src="<?php echo plugins_url() ?>/payu/img/icons/wordpress.png" target="_blank" /></a>
					<a href="https://github.com/eticsoft/"><img src="<?php echo plugins_url() ?>/payu/img/icons/github.png" target="_blank" /></a>
				</div>
			</div>
		</div>
	</div>
</div>
<form style="display:none">