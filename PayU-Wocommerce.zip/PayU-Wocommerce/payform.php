<?php
if (!defined('ABSPATH')) {
	exit;
}
?>
<div class="spp_bootstrap-wrapper">


<script>
    var $ = jQuery;
<?php /* if ($c_auto_currency == "on" AND $currency->name != 'TRY'): ?>
  setCurrency({$currency_default);
  alert('Seçtiğiniz para birimi bu ödeme yönteminde kullanılamıyor. Kurunuz <?php echo $currency->name ?> olarak değiştrildi.')
  <?php endif; */ ?>
    var protrccname = '<?php echo __('Your Name') ?>';
    var currency_sign = "<?php echo $currency->sign ?>";
    var card = new Array();
    var cards = new Array();
    var payuuri = "<?php echo plugins_url() ?>/payu/";
    var defaultins = "<?php echo $defaultins['total'] ?>";
<?php foreach ($cards as $family => $frates): ?>
	    cards ['<?php echo $family ?>'] = new Array();
	<?php foreach ($frates as $div => $ins): ?>
		<?php if ($c_min_inst_amount < $ins['month']): ?>
			    cards["<?php echo $family ?>"]["<?php echo $div ?>"] = "<?php echo $ins['total'] ?>";
		<?php endif; ?>
	<?php endforeach; ?>
<?php endforeach; ?>
</script>

	<div class="row" id="spp_top">
		<div class="col-xs-12 col-lg-6" align="center">
			<h2><?php echo __('Kredi Kartı ile Güvenli Ödeme') ?></h2>
			<small>
				<?php echo __('Bu sayfa SSL şifreli bir form üzerinden güvenli bir şekilde kredi kartı ödemesi yapmanızı sağlar.') ?><br/>
				<?php echo __('3D Güvenli sayfaya yönlendirebilir ve SMS şifrenizi kullanabilirsiniz.') ?>
			</small>
		</div>
		<div class="col-xs-12 col-sm-6 hidden-md-down" align="center">
			<img class="img-responsive" src="<?php echo plugins_url() ?>/payu/img/safepayment.png"/>
		</div>
	</div>

	<?php if ($error_message) : ?>
		<div class="row">
			<div class="alert alert-danger" id="errDiv">
				<div class="spperror" id="errDiv">
					<?php echo __('Ödeme başarısız. Banka cevabınız:') ?> <br/><?php echo $error_message ?><br/>
					<?php echo __('Lütfen formu kontrol edip tekrar deneyin.') ?>
				</div>
			</div>
		</div>
	<?php endif; ?>
	<hr/>
	<?php if ($mp): ?>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
		<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
		
		<script type="text/javascript" src="<?php echo plugins_url() ?>/payu/views/js/mfs-client.min.js" ></script>
		<?php echo $mp->ui['forms']['js_init'] ?>
		<script type="text/javascript" src="<?php echo plugins_url() ?>/payu/views/js/masterpass.js" ></script>

		<form id="masterpass_payform" method="post" action="#">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<div id="eticsoftMP_cardList_container" style="display:none">
						<div class="list-header">
							<img id="eticsoftMP_cardList_container_img" src="<?php echo plugins_url() ?>/payu/img/masterpass.svg" class="img-responsive">
							<span class="btn btn-info pull-right" id="usesavedcard" style="display:none">
								<?php echo __('Use a saved card') ?>
							</span>
						</div>
						<ul class="" id="eticsoftMP_cardList">
						</ul>
						<div class="eticsoftMP_cartitem2 row">
							<div class="col-md-6">
								<a id="usenewcard" class="btn btn-info" style="color:#fff" ><span class="glyphicon glyphicon-plus"></span> <?php echo __('Use another credit card') ?></a>
							</div>
							<div class="col-md-6">
								<a class="btn btn-warning" style="text-align:right; color:#fff" id="emp_delete_cc" > <?php echo __('Delete Selected Card') ?></a>
							</div>
						</div>
					</div>
				</div>
		</form>
		<div class="col-lg-6 col-md-12">
			<div id="mp_tx_selected_holder" style="display:none">
				<div id="eticsoftMP_scard_display">	
					<select class="form-control input-lg" name="cc_installment" id="mp_installment_select">
						<option value="1"> Tek Çekim </option>
					</select>
				</div>

				<hr/>
				<small><?php echo __('The amount will be charged your credit card is :') ?></small>
				<div id="eticsoftMP_totalToPay"></div>
				<hr/>
				<input name="cc_family" id="mp_tx_selected_holder_family" type="hidden"/>
				<input id="mp_tx_selected_holder_cc_id" name="cc_id" type="hidden"/>
				<input id="mp_tx_selected_holder_cc_name" name="cc_name" type="hidden"/>
				<input id="mp_tx_selected_holder_cc_number" name="cc_number" type="hidden"/>
				<input id="mp_tx_selected_holder_cc_expiry" name="cc_expiry" type="hidden"/>
				<div id="mp_tx_selected_holder_total_pay"> 
					<div id="emp_form_cardcvv">
						<input type="text" size="3" style="font-size:1.5em" name="cc_cvv" placeholder="CVV" id="emp_cc_cvv"/>
						<img width="80px" src="<?php echo plugins_url() ?>/payu/img/cvv.png" style="vertical-align: bottom;">
					</div>
					<br/>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-info">Ödemeyi Tamamla </button>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>

<!-- Button to Open the Modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  Open modal
</button>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        Modal body..
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<form novalidate action="<?php echo $order->get_checkout_payment_url(true);?>" autocomplete="on" method="POST" id="cc_form">
	<div class="row">
		<div class="col-xs-12 col-md-12 col-lg-6" align="center" id="cc_form_table">
			<div class="row" >
				<div class="col-xs-12 col-sm-6 col-md-6">
					<?php echo __('Kart Numarası') ?><br/>
					<input type="text" id="cc_number" name="cc_number" class="cc_input form-control input-lg" placeholder="•••• •••• •••• ••••" 
						   value="<?php if (Etictools::getValue('cc_number')): ?><?php echo Etictools::getValue('cc_number') ?><?php endif; ?>"/>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<?php echo __('Son Kullanma Tarihi') ?><br/>
					<input type="text" id="cc_expiry" name="cc_expiry" class="cc_input form-control input-lg" placeholder="<?php echo __('AA/YY') ?>" 
						   value="<?php echo Etictools::getValue('cc_expiry') ?>"/>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6">
					<?php echo __('CVV') ?> <br/>
					<input type="text" id="cc_cvc" name="cc_cvv" class="cc_input form-control input-lg" placeholder="•••" 
						   value="<?php echo Etictools::getValue('cc_cvv') ?>"/>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<?php echo __('Kart Sahibinin Adı') ?><br/>
					<input type="text" id="cc_name" name="cc_name" class="cc_input form-control input-lg" placeholder="<?php echo __('Adınız') ?>" 
						   value="<?php echo Etictools::getValue('cc_name') ?>"/>
				</div>
			</div>
			<hr/>
			<div class="row">
				<div class="col-xs-12 col-sm-4">
					<select name="cc_family" id="tx_bank_selector" class="form-control" data-no-uniform="true">
						<option value="all"><?php echo __('Tüm Kartlar') ?></option>
						<?php foreach ($cards as $family => $rate): ?>
							<option value = "<?php echo $family ?>"><?php echo ucfirst($family) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="col-xs-12 col-sm-8">
					<div id="tx_selected_holder" class="pull-left">

					</div>
				</div>
			</div>
		</div>
		<div class="col-xs-12 col-md-6 hidden-md-down">
			<div id="card-wrapper"></div>
			<div id="prefix_bank_logo" align="center"></div>
			<div id="prefix_bank" align="center"></div>
		</div>
	</div>

	<div class="row text-center" style="text-align:center">
		<hr/>
		<button name="payu_submit" type="submit" id="cc_form_submit" align="center" class="btn btn-lg btn-primary"><?php echo __('Ödemeyi Onayla') ?></button>
	</div>
	<?php if ($mp): ?>
		<div class = "row text-center" id = "mp_register_container" style = "text-align:center">
			<?php echo $mp->ui['forms']['registerMPcheck'] ?>
			<?php echo $mp->ui['forms']['registerMPcontainer'] ?>
		</div>
	<?php endif; ?>
</form>

<?php foreach ($cards as $family => $rate): ?>
	<div class = "tx_banka" style = "display:none" id = "tx_banka_<?php echo $family ?>">
		<select style = "min-width:200px" class = "cc_installment_select cc_input form-control" name="cc_installment" id = "tx_inst_<?php echo $fam ?>">
			<?php foreach ($rate as $div => $installment): ?>
				<option value = "<?php echo $div ?>" dataamount = "<?php echo $installment['total'] ?>">
					<?php if ($div == 1) : ?>
						<?php echo __('Tek çekim ödeme') ?> 
						<?php if ($installment['rate'] == 0): ?> <?php echo __('Komisyonsuz') ?>
						<?php else: ?> <?php echo $installment['total'] . ' ' . $currency->sign ?>
						<?php endif; ?>
						<?php else: ?>
						<?php echo $div ?> <?php echo __('Taksit') ?> X <?php echo $installment['month'] ?>
						<?php if ($installment['rate'] == 0): ?> <?php echo __('Komisyonsuz') ?>
						<?php else: ?> <?php echo __('Total') ?> <?php echo $installment['total'] . ' ' . $currency->sign ?> <?php endif; ?>
					</option>
				<?php endif; ?>
			<?php endforeach; ?>
		</select>
	</div>
<?php endforeach; ?>
<div class="tx_banka" style="display:none" id="tx_banka_all">
	<select style="min-width:200px"  class="cc_installment_select cc_input form-control" name="cc_installment" id="tx_inst_all">
		<option value="1" dataamount="<?php echo $defaultins['total'] ?>"> <?php echo __('Tek çekim ödeme') ?></option>
	</select>
</div>
<br/>
<br/>
<hr/>
<?php if ($mp): ?>
	<div class = "modal fade emp_modal" id = "eticsoftMP_loader" role = "dialog">
		<div class = "modal-dialog">
			<div class = "modal-content">
				<div class = "modal-body">
					<h2 align = "center">Lütfen Bekleyin<h2>
							<div id = "eticsoftMP_loaderImg"></div>
							</div>
							</div>
							</div>
							</div>

							<div class = "modal fade emp_modal" id = "eticsoftMP_message_panel" role = "dialog">
								<div class = "modal-dialog">
									<div class = "modal-content">
										<div class = "modal-header">
											<button type = "button" class = "close" data-dismiss = "modal" aria-label = "Close">
												<span aria-hidden = "true">X</span>
											</button>
											<img src = "<?php echo plugins_url() ?>/payu/img/masterpass.svg" class = "img-responsive">
										</div>
										<div class = "modal-body">
											<h2 align = "center" id = "eticsoftMP_message_title">Bir hata oluştu</h2>
											<div id = "eticsoftMP_message_text" class = "alert alert-warning"></div>
										</div>
									</div>
								</div>
							</div>
							<div id = "eticsoftMP_container" style = "font-size:.8em">
								<?php echo $mp->ui['forms']['checkMP'] ?>
								<?php echo $mp->ui['forms']['otp'] ?>
								<?php echo $mp->ui['forms']['mpin'] ?>
								<?php echo $mp->ui['forms']['linkCardtoClient'] ?>
								<?php echo $mp->ui['forms']['tos'] ?>
							</div>
						<?php endif; ?>
						<div class="row">
							<a href="<?php echo $order->get_checkout_payment_url()?>" class="button_large"><?php echo __('Diğer ödeme yöntemleri') ?></a>
						</div>
						</div>