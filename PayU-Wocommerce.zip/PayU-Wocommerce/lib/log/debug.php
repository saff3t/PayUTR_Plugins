<?php exit; ?>
2018-04-04 15:44:31 TR 1
*   Trying 213.153.232.48...
* TCP_NODELAY set
* Connected to sanalpos.teb.com.tr (213.153.232.48) port 443 (#0)
* ALPN, offering http/1.1
* Cipher selection: ALL:!EXPORT:!EXPORT40:!EXPORT56:!aNULL:!LOW:!RC4:@STRENGTH
* SSL connection using TLSv1.2 / ECDHE-RSA-AES128-GCM-SHA256
* ALPN, server did not agree to a protocol
* Server certificate:
*  subject: C=TR; ST=istanbul; L=istanbul; O=TURK EKONOMI BANKASI A.S.; OU=Bilgi Teknolojileri; CN=sanalpos.teb.com.tr
*  start date: Aug  8 00:00:00 2017 GMT
*  expire date: Oct  1 23:59:59 2020 GMT
*  issuer: C=US; O=GeoTrust Inc.; CN=GeoTrust SSL CA - G3
*  SSL certificate verify result: unable to get local issuer certificate (20), continuing anyway.
> POST /servlet/cc5ApiServer HTTP/1.1
Host: sanalpos.teb.com.tr
Accept: */*
Content-Length: 922
Content-Type: application/x-www-form-urlencoded

* upload completely sent off: 922 out of 922 bytes
< HTTP/1.1 200 OK
< Date: Wed, 04 Apr 2018 12:44:33 GMT
< Server: NONE
< Strict-Transport-Security: max-age=31536000; includeSubDomains
< Content-Type: text/xml;charset=ISO-8859-9
< Content-Length: 505
< Connection: close
< 
* Curl_http_done: called premature == 0
* Closing connection 0

2018-04-04 15:46:25 TR 1
*   Trying 213.153.232.48...
* TCP_NODELAY set
* Connected to sanalpos.teb.com.tr (213.153.232.48) port 443 (#0)
* ALPN, offering http/1.1
* Cipher selection: ALL:!EXPORT:!EXPORT40:!EXPORT56:!aNULL:!LOW:!RC4:@STRENGTH
* SSL connection using TLSv1.2 / ECDHE-RSA-AES128-GCM-SHA256
* ALPN, server did not agree to a protocol
* Server certificate:
*  subject: C=TR; ST=istanbul; L=istanbul; O=TURK EKONOMI BANKASI A.S.; OU=Bilgi Teknolojileri; CN=sanalpos.teb.com.tr
*  start date: Aug  8 00:00:00 2017 GMT
*  expire date: Oct  1 23:59:59 2020 GMT
*  issuer: C=US; O=GeoTrust Inc.; CN=GeoTrust SSL CA - G3
*  SSL certificate verify result: unable to get local issuer certificate (20), continuing anyway.
> POST /servlet/cc5ApiServer HTTP/1.1
Host: sanalpos.teb.com.tr
Accept: */*
Content-Length: 922
Content-Type: application/x-www-form-urlencoded

* upload completely sent off: 922 out of 922 bytes
< HTTP/1.1 200 OK
< Date: Wed, 04 Apr 2018 12:46:27 GMT
< Server: NONE
< Strict-Transport-Security: max-age=31536000; includeSubDomains
< Content-Type: text/xml;charset=ISO-8859-9
< Content-Length: 505
< Connection: close
< 
* Curl_http_done: called premature == 0
* Closing connection 0
