<?php

Class EticConfig
{

	public static $order_themes = array(
		'pro' => 'PRO!tema (Önerilir)',
		// '3d' => 'Üç boyutlu JS tema (Seksi)',
		// 'cr' => 'Kredity Form (Resmi)',
		// 'st' => 'Basit standart form '
	);
	public static $installment_themes = array(
		'color' => 'Renkli (Önerilir)',
		'simple' => 'Basit (Renksiz)',
		'white' => 'Beyaz (Resmi)',
		'colorize' => 'Colorize (Seksi) '
	);
	public static $families = array(
		'axess', 'bonus', 'maximum', 'cardfinans', 'world', 'paraf', 'advantage'
	);
	public static $messages = array();
	public static $gateways;

	public static function get($key)
	{
		return get_option($key);
	}

	public static function set($key, $value)
	{
		return update_option($key, $value);
	}

	public static function getAdminGeneralSettingsForm($module_dir)
	{
		$t = '<form action="" method="post" id="general_settings_form" >
			<div class="panel">
				<div class="row ">
					<div class="col-md-8"> <!-- required for floating -->
				
				</div>
				<div class="col-md-4"> 
					<a class="btn btn-default pull-right" href="#help" role="tab" data-toggle="tab"><i class="process-icon-help"></i> Yardım</a> 
					<button type="submit" name="submitspr" class="btn btn-default pull-right"><i class="process-icon-save"></i> Ayarları Kaydet</button>
				</div>
			</div>';

		$t .= '
			<h2>Genel Ayarlar</h2>
			<div class="row">';
// Enable Disable
		$woo_settings = get_option("woocommerce_payu_settings");

		$t .= '
            <div class="col-md-3 text-center sppbox ' . ($woo_settings['enabled'] == 'yes' ? 'bggreen ' : 'bgred') . '">
                <h2>Eklenti Aktif ?</h2>
                <select class="form-control" name="WOO_POSPRO_SETTINGS[enabled]">
                    <option value="yes"> Aktif </option>
                    <option value="no" ' . ($woo_settings['enabled'] == 'no' ? 'SELECTED ' : '') . '> Pasif </option>
                </select>
                <br/>
                Eklentiyi aktifleştir.<br/>
                <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
            </div>';

// Hata Kayıt Modu
		// $t .= '
            // <div class="col-md-3 text-center sppbox ' . (EticConfig::get("POSPRO_DEBUG_MOD") == 'on' ? 'bgred ' : 'bggray') . '">
                // <h2>Detaylı İşlem Kayıt</h2>
                // <select class="form-control" name="spr_config[POSPRO_DEBUG_MOD]">
                    // <option value="on" ' . (EticConfig::get("POSPRO_DEBUG_MOD") == 'on' ? 'SELECTED ' : '') . '> Açık </option>
                    // <option value="off" ' . (EticConfig::get("POSPRO_DEBUG_MOD") == 'off' ? 'SELECTED ' : '') . '> Kapalı </option>
                // </select>
                // <br/>
                // Tüm işlemleri incelemek üzere kaydeder.<br/>
                // <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
            // </div>';

//3D Auto Form
		// $t .= '
		// <div class="col-md-3 text-center sppbox bggray">
		// <h2>3DS Otomatik Yönlendirme</h2>
		// <select class="form-control" name="spr_config[POSPRO_ORDER_AUTOFORM]">
		// <option value="on" > Açık (önerilir)</option>
		// <option value="off" ' . (EticConfig::get("POSPRO_ORDER_AUTOFORM") == 'off' ? 'SELECTED ' : '') . ' > Kapalı </option>
		// </select>
		// <br/>
		// 3DS formlarını otomatik yönlendir.<br/>
		// <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		// </div>';
//currency
		// $t .= '<div class="col-md-3 text-center sppbox bggray">
                    // <h2>Otomatik TL çevirimi</h2>
                    // <select class="form-control" name="spr_config[POSPRO_AUTO_CURRENCY]">
                    // <option value="on"> Açık (önerilir)</option>
                    // <option value="off" ' . (EticConfig::get("POSPRO_AUTO_CURRENCY") == 'off' ? 'SELECTED ' : '') . '> Kapalı </option>
                    // </select>
                    // <br/>
                    // Yabancı kurlar ödemeleri TL ye çevirir<br/>
                    // <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
            // </div>';
//IPN

		$link = plugins_url().'/payu/ipn.php';


		$t .= '
		<div class="col-md-3 text-center sppbox bggray">
		<h2>IPN ile Doğrulama</h2>
		<select class="form-control" name="spr_config[POSPRO_IPN]">
		<option value="on" > Açık (önerilir)</option>
		<option value="off" ' . (EticConfig::get("POSPRO_IPN") == 'off' ? 'SELECTED ' : '') . ' > Kapalı </option>
		</select>
		<br/>
		IPN ile otomatik sipariş onayı. <br/> 
		<a href="https://payu.com/sikca-sorulan-sorular/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>
		
		<div class="col-md-3 text-center sppbox bggray">
			<div class="alert alert-warning">
					IPN ile doğrulama yapacaksanız PayU hesabınıza girip IPN ayarları bölümüne aşağıdaki URL adresini kaydetmelisiniz.<br/>
					<br/><textarea class="form-control">'.$link.'</textarea> 
					
			</div>
		</div>
		';

		$t .= '</div>'; //row
// Açıklama
		/*  $t .= '<div class="col-md-6 text-center sppbox bgred">
		  <h2>Önemli</h2>
		  Posların çoğu USD ve EUR codelarındaki ödemeleri kabul eder ve EticSoft PayU! tüm kurları destekler.
		  Fakat sanal POS hizmetinizin banka tanımlarında eksiklik ve hatalar olması gibi durumlarda hatalı veya başarısız ödemelerle karşılaşabilirsiniz.<br/>
		  <b>Para birimlerinin ISO ve Numerik codelarını doğru girmeniz oldukça önemlidir. Örneğin Türk lisasının ISO codeu "TRY" dir.</b>
		  <br/>
		  <br/>
		  </div>
		  </div>';
		 */

		$t .= '<h2>Taksit Ayarları</h2>
		<div class="row">';
		$default_rate = EticInstallment::getDefaultRate();
		$gwas = EticGateway::getGateways(true);

		if ($gwas) {

			$t .= '<div class="col-md-3 text-center sppbox bggray">
		<h2>Min Taksit Tutarı</h2>
		<input name="spr_config[POSPRO_MIN_INST_AMOUNT]" size="4" class="form-control" value="' . (float) Eticconfig::get('POSPRO_MIN_INST_AMOUNT') . '" type="text"/><br />
		Taksit seçeneğinin aylık tutarı en az bu kadar olmalıdır. (TL)<br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>';


			$t .= '<div class="col-md-3 text-center sppbox bggray">
		<h2>Varsayılan POS</h2>';
			$t .= '<select name="spr_config_default_gateway" class="form-control">';
			foreach ($gwas as $gw)
				$t .= '<option value="' . $gw->name . '" ' . ($default_rate['gateway'] == $gw->name ? ' selected ' : '') . '>' . $gw->full_name . '</option>';
			$t .= '</select>'
				. '<br />
		Taksit yapılamayan kartlar için bu POS\'u kullan.<br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
        </div>';

			$t .= '<div class="col-md-3 text-center sppbox bggray">
		<h2>Tek Çekim Komisyonu </h2>
		<input name="spr_config_default_rate" class="form-control" size="4" value="' . (float) $default_rate['rate'] . '" type="number" step="0.01"/><br />
		Varsayılan POS kullanıldığı zaman müşteriye yansıtılacak yüzde.<br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>';

			$t .= '<div class="col-md-3 text-center sppbox bggray">
		<h2>Tek Çekim Maliyeti </h2>
		<input name="spr_config_default_fee" size="4" class="form-control" value="' . (float) $default_rate['fee'] . '" type="number" step="0.1"/><br />
		Varsayılan POS kullanıldığı zaman sizden kesilecek yüzde <br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>';
		} else {
			$t .= '<div class="alert alert-danger">Kurulu POS hizetiniz bulunamadı. Lütfen önce bir POS kurulumunu yapınız</div>';
		}

		$t .= '</div>';



		$t .= '<h2>Görünüm Ayarları</h2>
		<div class="row">';

// taksitleri göster
		$t .= '
		<div class="col-md-3 text-center sppbox bggray">
		<h2>Taksitler Sekmesi</h2>
		<select name="spr_config[POSPRO_TAKSIT_GOSTER]" class="form-control">
		<option value="on"> Göster </option>
		<option value="off" ' . (EticConfig::get("POSPRO_TAKSIT_GOSTER") == 'off' ? 'SELECTED ' : '') . ' > Gizle </option>
		</select>
		<br/>
		Ürün sayfasının altında bulunan taksit seçenekleri.<br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>';

// PDF göster
		/* $t .= '
		  <div class="col-md-3 text-center sppbox bggray">
		  <h2>PDF Yerleşimi</h2>
		  <select name="spr_config[POSPRO_HOOK_PDF]" class="form-control">
		  <option value="Goster"> Göster </option>
		  <option value="Gizle" ' . (EticConfig::get("POSPRO_HOOK_PDF") == 'off' ? 'SELECTED ' : '') . ' > Gizle </option>
		  </select>
		  <br/>
		  PDF faturaya kredi kartı işlem bilgileri (silip) eklensin mi ?.<br/>
		  <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		  </div>';
		 * 
		 */

// ödeme tema
		$t .= '
		<div class="col-md-3 text-center sppbox bggray">
		<h2>Ödeme Ekranı Teması</h2>
		<select name="spr_config[POSPRO_PAYMENT_PAGE]" class="form-control">';
		foreach (EticConfig::$order_themes as $k => $v):
			$t .= '<option value="' . $k . '" ' . (EticConfig::get("POSPRO_PAYMENT_PAGE") == $k ? 'SELECTED ' : '') . '>' . $v . '</option>';
		endforeach;
		$t .= '</select>
		<br/>
		Ödeme sayfanızın yapısını seçiniz<br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>';
// taksit tema
		$t .= '<div class="col-md-3 text-center sppbox bggray">
		<h2>Taksitler Tema</h2>
		<select name="spr_config[POSPRO_PRODUCT_TMP]" class="form-control">';
		foreach (EticConfig::$installment_themes as $k => $v):
			$t .= '<option value="' . $k . '" ' . (EticConfig::get("POSPRO_PRODUCT_TMP") == $k ? 'SELECTED ' : '') . '>' . $v . '</option>';
		endforeach;
		$t .= '</select>
		<br/>
		Taksit seçenekleri sekmesinin görünümü.<br/>
		<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		</div>
		<div class="col-md-3 text-center sppbox bggreen">
		</div>
		</div><hr/>';
		
		$t .= '<div class="row">
		<div class="alert alert-warning"><h2>Uyarı</h2>PayU! tüm para birimlerini destekler. 
		Fakat yabancı kurlarda ödeme alabilmeniz için hizmet aldığınız POS altyapısının da desteklemesi gerekir. 
		</div>
		</div>
		<div class="panel">
		<div class="panel-header">
		<a href="https://eticsoft.com/" target="_blank">
		  <img class="align_center" src="' . plugins_url() . '/payu/img/eticsoft-logo-250px.png"/>
		</a>
		<h4><a href="https://eticsoft.com/" target="_blank">EticSoft R&D Lab</a> tarafından geliştirilmiştir.</h4>
		</div>
		<div class="panel-body">
			<div class="row eticsoft_garantipay-header">
				<div class="col-xs-6 col-md-4 text-center">
					<iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FEticSoft%2F&width=450&layout=standard&action=like&size=small&show_faces=true&share=true&height=80&appId=166162726739815" width="450" height="80" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>		</div>
				<div class="col-xs-6 col-md-8 text-center">
				<a href="https://www.youtube.com/user/EticSoft"><img src="' . plugins_url() . '/payu/img/icons/youtube.png" target="_blank" /></a>
				<a href="https://www.linkedin.com/company/eticsoft-yaz%C4%B1l%C4%B1m"><img src="' . plugins_url() . '/payu/img/icons/linkedin.png" target="_blank" /></a>
				<a href="https://twitter.com/eticsoft"><img src="' . plugins_url() . '/payu/img/icons/twitter.png" target="_blank" /></a>
				<a href="https://www.instagram.com/eticsoft/"><img src="' . plugins_url() . '/payu/img/icons/instagram.png" target="_blank" /></a>
				<a href="https://wordpress.org/support/users/eticsoft-lab/"><img src="' . plugins_url() . '/payu/img/icons/wordpress.png" target="_blank" /></a>
				<a href="https://github.com/eticsoft/"><img src="' . plugins_url() . '/payu/img/icons/github.png" target="_blank" /></a>
				</div>
			</div>
		</div>
	</div>';
		


		$t .= '<input name="conf-form" type="hidden" value="1" />
		</div>
		' . wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . ' 
		</form>';
		return $t;
	}

	public static function getMasterPassForm()
	{
		$t = '
			<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js" integrity="sha384-SlE991lGASHoBfWbelyBPLsUlwY1GwNDJo3jSJO04KZ33K2bwfV9YBauFfnzvynJ" crossorigin="anonymous"></script>

			<form action="" method="post" id="masterpass_settings_form" action="#masterpass">
			<div class="panel">
				<div class="row ">
					<div class="col-md-8"> <!-- required for floating -->
						<p class="alert alert-info"><b>Masterpass</b> MasterCard tarafından sağlanan bir e-cüzdan sistemidir.
						<b>Masterpass</b> cüzdan hesabı olan kullanıcılara tek tıkla ödeme seçeneği gösterir.
						Masterpass hesabı olmayan müşterileriniz için ise hiç bir şey değişmez. Eskisi gibi kart bilgilerini girerek ödeme yaparlar.
						<b>Masterpass</b> mağazanızın ödeme sayfasını değiştirmeden ek bir seçenek olarak 
						çalışır. Ödemeleriniz eskisi gibi anlaşmalı olduğunuz bankanın posundan çekilmeye devam eder.
						<b>Herhangi bir komisyon ücreti almaz ve ödemenize dokunmaz.</b> 
						
						</p>
					</div>
					<div class="col-md-4"> 
						<a class="btn btn-default pull-right" href="https://payu.com/masterpass-entegrasyon/" target="_blank" ><i class="process-icon-help"></i> Yardım</a> 
						<button type="submit" name="submitspr" class="btn btn-default pull-right"><i class="process-icon-save"></i> Ayarları Kaydet</button>
					</div>
				</div>	
				<div class="row">
					<h2>Masterpass Üye İşyeri Olmanız İçin 8 Neden</h2>

				</div>
			<div class="row">
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="fab fa-cc-mastercard mpicon" ></i><br/><br/>  BY MASTERCARD</h2>
						<p>Masterpass altyapısı tamamen MasterCard tarafından 
						sağlanan, dünyanın ve ülkemizin büyük markaları ve 
						alışveriş platformlarında kullanılan bir servistir.</p>
					</div>
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="fas fa-sync mpicon" ></i><br/><br/> POS DEĞİŞİKLİĞİ YOK !</h2>
						<p>Mevcut kullandığınız pos sistemini veya bankanızı 
						değiştirmenize gerek yok. Masterpass altyapısı sadece 
						bir cüzdan servisidir. Ödemeleriniz eskisi gibi kendi 
						sanalposunuzdan tahsil edilir.</p>
					</div>
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="far fa-money-bill-alt mpicon" ></i><br/><br/> 1 YIL ÜCRETSİZ DENEYİN</h2>
						<p>Masterpass e-cüzdan sistemini PayU! 
						sponsorluğu ile birlikte 1 yıl hiç bir ücret ödemeden 
						kullanabilirsiniz. Masterpass servisinde 
						hiç bir komisyon, ek ücret yoktur.</p>
					</div>
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="far fa-thumbs-up mpicon" ></i><br/><br/> ETICSOFT DESTEĞİ </h2>
						<p>Bu eklentiyi Masterpass işbirliği kapsamında biz geliştirdik.
						İhtiyaç duyduğunuz tüm teknik desteği <b>ÜCRETSİZ</b> olarak biz sağlıyoruz.
						</p>
					</div>
					<div class="col-sm-3 sppbox spph250 ">
						<h2><i class="fas fa-user-secret mpicon" ></i><br/><br/>  DAHA GÜVENLİ !</h2>
						<p>Masterpass tarafından sağlanan ek kullanıcı doğrulama, cep telefonu doğrulama ve 
						kart sahipliği doğrulama fonksiyonları sayesinde alışverişler daha güvenli olur.</p>
					</div>
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="fas fa-fighter-jet mpicon"></i><br/><br/> DAHA HIZLI ÖDEME !</h2>
						<p>Masterpass kullanan müşterileriniz tek tıkla ödeme yapar. 
						Kart bilgilerinin bankaya iletilmesi siteniz üzerinden değil Masterpass üzerinden sağlanır.
						</p>
					</div>
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="fas fa-magic mpicon" ></i><br/><br/> DAHA ŞIK !</h2>
						<p>Masterpass entegrasyonu yaptığınızda PayU! ödeme sayfanıza 
						oldukça sade ve şık bir UI/UX tasarımı belirir. Bu standartlar 
						Masterpass tarafından belirlenmektedir.</p>
					</div>
					<div class="col-sm-3 sppbox spph250">
						<h2><i class="fas fa-power-off mpicon" ></i><br/><br/> TEK TIKLA AÇ/KAPAT !</h2>
						<p>Masterpass entegrasyonunu bu sayfadan istediğiniz an kapatabilir, entegrasyonu by-pass ederek pasifleştirebilirsiniz. 
						Kapattığınız an ödeme sayfanız tamamen eskisi gibi çalışır.
						</p>
					</div>
				</div>
				<div class="row">
					<p class="alert alert-info"> EticSoft R&D lab olarak, MasterCard ile Masterpass projesinde 
					işbiriliği ve sponsorluk konularında bir anlaşma imzaladık. 
					Bu kapsamda Opensource (açık kaynak) e-ticaret platformlarındaki 
					Masterpass standartlarına uygun eklentilerin geliştirmelerini,
					eklentilerin dağıtımı, tanıtımı ve teknik desteğini ücretsiz olarak biz sağlıyoruz. 
					Kullandığınız bu eklentinin tüm teknik sürecin arkasında biz olduğumuz gibi 
					Masterpass sürecinizde de sizin yanınızda olacağız.				
					</p>
				</div>

				<hr/>
				<div class="row ">
					<div class="col-md-4 text-center sppbox ' . (EticConfig::get("MASTERPASS_ACTIVE") != 'on' ? 'alert-danger ' : 'alert-success') . '">
						<h2>Durum</h2>
						<select name="spr_config[MASTERPASS_ACTIVE]">
							<option value="on"> Aktif </option>
							<option value="off" ' . (EticConfig::get("MASTERPASS_ACTIVE") != 'on' ? 'SELECTED ' : '') . '> Pasif </option>
						</select>
						<br/>
						MasterPass sistemini aktif eder.<br/>
						<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
					</div>';
		$t .= '
					<div class="col-md-4 text-center sppbox bggray">
						<h2>MasterPass Client ID</h2>
						<input name="spr_config[MASTERPASS_CLIENT_ID]" class="form-control" size="4" value="' . (float) Eticconfig::get('MASTERPASS_CLIENT_ID') . '" type="number"/><br />
						Masterpass tarafından sağlanan mağaza ID no<br/>
						<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
					</div>';
		$t .= '
					<div class="col-md-4 text-center sppbox bggray">
						<h2>MasterPass Ortamı</h2>
						<select name="spr_config[MASTERPASS_STAGE]">
							<option value="TEST"> Test Ortamı </option>
							<option value="UAT" ' . (EticConfig::get("MASTERPASS_STAGE") == 'UAT' ? 'SELECTED ' : '') . '> UAT Ortam </option>
							<option value="PROD" ' . (EticConfig::get("MASTERPASS_STAGE") == 'PROD' ? 'SELECTED ' : '') . '> Canlı Ortam </option>
						</select><br/>
						MasterPass ortam seçimi. Test ortamında ödemeler gerçekten tahsil edilmez.<br/>
						<a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
					</div>';
		$t .= '</div>';
		/*
		  $t .= '
		  <div class="row">
		  <div class="col-md-3 panel">
		  <h2>Participant number</h2>
		  <input name="spr_config[MASTERPASS_PART_NO]" class="form-control"  value="' . Eticconfig::get('MASTERPASS_PART_NO') . '" /><br />
		  Masterpass tarafından sağlanan Program participant name <br/>
		  <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		  </div>
		  <div class="col-md-3 panel">
		  <h2>Participant name</h2>
		  <input name="spr_config[MASTERPASS_PART_NAME]" class="form-control" value="' . Eticconfig::get('MASTERPASS_PART_NAME') . '" /><br />
		  Masterpass tarafından sağlanan Program participant number <br/>
		  <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		  </div>
		  <div class="col-md-3 panel">
		  <h2>MasterPass sponsor No</h2>
		  <i>PS702973</i><br /><hr/>
		  Masterpass sponsorluk no <br/>
		  <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		  </div>
		  <div class="col-md-3 panel">
		  <h2>MasterPass sponsor Name</h2>
		  <i>Eticsoft Sponsor</i><br /><hr/>
		  Masterpass sponsor adı <br/>
		  <a href="https://payu.com/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
		  </div>
		  </div>';
		 * 
		 */
		$t .= '		
				<div class="row">
					<div class="col-md-8"> 
						<i>
							Enc ' . EticConfig::get("MASTERPASS_ENC_KEY") . ' Mac ' . EticConfig::get("MASTERPASS_MAC_KEY") . ' Last' . date("Y-m-d H:i:s", (int) EticConfig::get('MASTERPASS_LAST_KEYGEN')) . '
						</i>
					</div>
					<div class="col-md-4"> 
						<a class="btn btn-default pull-right" href="https://payu.com/destek/" target="_blank" ><i class="process-icon-help"></i> Yardım</a> 
						<button type="submit" name="submitspr" class="btn btn-default pull-right"><i class="process-icon-save"></i> Ayarları Kaydet</button>
					</div>

				<div>';
		/*
		  $t .= '	<div class="row">
		  <div class="col-md-12">
		  <h2>Entegrasyon Adımları Nelerdir ?</h2>
		  <ol>
		  <li><a href="https://eticsoft.com/masterpass-sozlesmesi.pdf" target="_blank">Bu adresten</a>
		  Masterpass İşlem Yönlendirme Hizmeti Taahhütnamesini indirip inceleyin.
		  Başvuru için tüm sayfalarını imzalayın ve kaşe basın.</li>
		  <li> Onaylandığınız zaman size Masterpass üye iş yeri bilgilerinizi göndereceğiz.  </li>
		  <li> Bu sayfadaki forma bu bilgileri giriniz. Bizim ve Masterpass ekibinin bir test uzmanı entegrasyonu test edecek. </li>
		  <li> Hepsi bu kadar. Dilerseniz Masterpass üye işyeri ikonunu sitenizin altına ekleyebilirsiniz. Desteğe ihtiyacınız olduğunda biz yanınızda olacağız. </li>
		  </ol>
		  </div>
		  </div>
		  ';
		 */
		$t .= '</div><input name="conf-form" type="hidden" value="1" />'
			. wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . ' 
		</form>';
		return $t;
	}

	public static function getAdminGatewaySettingsForm($module_dir)
	{
		$gateways = EticGateway::$gateways;
		if (!EticGateway::getGateways()) {
			return '<div class="panel text-center"> <i style="font-size:60px" class="process-icon-cancel"></i><br/> '
				. '<h1> Henüz hiç bir Sanal POS hizmeti kurulmamış !</h1>'
				. '<p>SanalPOS hizmeti aldığınız banka veya ödeme kuruluşlarının hizmetlerini '
				. '<a role="tab" data-toggle="tab" href="#integration"> Ödeme Yöntemleri </a> sekmesinden kurabilirsiniz.</p>'
				. ''
				. '</div>';
		}
		$t = '<form action="#pos" method="post" id="bank_settings_form" class="sppform ">
			<div class="panel">
				<div class="row ">
                    <div class="col-md-6"> <!-- required for floating -->
                        <h2>Pos ayarları</h2>
                        
                    </div>
                    <div class="col-md-6"> 

                        <button type="submit" name="submit" class="btn btn-default pull-right"><i class="process-icon-save"></i> Tümünü Kaydet</button>
                        <input type="hidden" name="submitgwsetting" value="1"/>
                    </div>
                </div>
        <div class="row">
            <div class="col-md-2"> <!-- required for floating -->
                <!-- Nav tabs -->
                <ul class="nav nav-pills nav-stacked">
                    ';
		$satir = 0;
		foreach (EticGateway::getGateways(false) as $gwbutton):
			$t .= '<li class="' . ($satir == 0 ? 'active' : '' ) . '">
                            <a href="#bf_' . $gwbutton->name . '_form" data-toggle="tab">
                                <img src="' . plugins_url() . '/payu/img/gateways/' . $gwbutton->name . '.png" width="125px"/>
                            </a>
                        </li>';
			$satir++;
		endforeach;
		

		$t .= '</ul>
            </div>

            <div class="col-md-10 ">
                <!-- Tab panes -->
                <div class="tab-content">';
		$satir = 0;
		foreach (EticGateway::getGateways(false) as $gwd):
			if ($gw = New EticGateway($gwd->name)):

				$gwe = EticGateway::$gateways->{$gw->name};
				if (!isset($gwe->families)) {
					continue;
				}


				//print_r(EticGateway::$gateways); exit;
				$t .= '<!-- BANKA -->

                        <div class="' . ($satir == 0 ? 'active' : '') . ' tab-pane" id="bf_' . $gw->name . '_form">
                            <div class="col-md-7 sppbox bggray">
                                <input name="pdata[' . $gw->name . '][id_bank]" type="hidden" value="' . $gw->name . '" />
                                <h2>' . $gw->full_name . ' Pos Ayarları </h2>
                                <hr/>';
				if (isset($gw->params->test_mode) && $gw->params->test_mode == 'on'):
					$t .= '<div class="alert alert-danger">' . $gw->full_name . ' test modunda çalışıyor. '
						. 'Test modunda yapılan siparişlerin başarılı görünür fakat ödemesi alınmaz. </div>';
				endif;
				$t .= '<h2>Parametreler</h2>' . $gw->createFrom();

				$t .= ' <br/>
						<div class="row">
                        <button type="submit" value="' . $gw->name . '" name="submit_for" class="btn btn-success"><i class="icon icon-save"></i> Ayarları Kaydet</button> 
						</div>

			<hr/>
			<br/>
			</div>
			<div class="col-md-5 sppbox bggray text-center">
			<h2><img src="' . plugins_url() . '/payu/img/gateways/' . $gw->name . '.png"/></h2>';

				if (json_decode($gwe->families)):
					$t .= '<div style="line-height:25px"> <span>Taksit yapabildiği kartlar:</span><br/>';
					foreach (json_decode($gwe->families) as $family):
						$t .= '<img class="img-thumbnail" width="90px" src="' . plugins_url() . '/payu/img/cards/' . $family . '.png"/>';
					endforeach;
					$t .= '</div>';
				endif;


				$t .= '<div id="' . $satir . '-kmp" >
                    
    			<table class="table">';

				$t .= '</table>
			</div>
			<a href="https://payu.com.tr/destek/" class="btn btn-info btn-large" target="_blank"><i class="icon-question-sign"></i> Açıklama </a>
            
            
            
            <div id="' . $gw->name . '_remove" class="collapse">
                <div class="panel">
                    <div class="alert alert-danger"> Dikkat! POS silme işlemi geri alınamaz. 
                    Sildiğiniz POS\'u daha sonra yeniden kurabilirsiniz. Fakat
                    ' . $gw->full_name . ' için girdiğiniz kullanıcı bilgileri ve oranlar da silinecektir.</div>
                    <div class="toggle"><button type="submit" class="btn btn-danger" name="remove_pos" value="' . $gw->name . '">Kaldır</button></div>
                </div>
            </div>
			</div>';

				if (EticTools::getValue('adv')):
					$t .= '<div class="col-sm-6">
					<input name="' . $gw->name . '[lib]" value="' . $gw->lib . '"/>
				</div>';
				endif;


				$t .= '</div>';
				$satir++;
			endif;
		endforeach;
		$t .= '
            
            </div>
            </div>

            </div>
            </div>
            <input name="bank-form" type="hidden" value="1" />
            ' . wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . ' 
		</form>';
		return $t;
	}

	public static function getAdminIntegrationForm()
	{

		$t = '
        <div class="panel">
            <div class="row">';
		$exists_gws = array();


		foreach (EticGateway::getGateways() as $gateway)
			$exists_gws [] = $gateway->name;



		$t .= '
            <div class ="col-md-12 panel">
            <h2>Kullanmak İstediğiniz POS servisini seçiniz</h2>
            EticSoft sadece BDDK lisanslı ve <b>güvenilir</b> ödeme kuruluşları ve bankalar ile entegrasyon sağlıyor.
            Kullanmak istediğiniz ödeme sistemi aşağıda yoksa, ilgili ödeme şirketi/banka standartlara 
            uygun bulunmamış veya bizimle hiç iletişime geçmemiş olabilir. 
			<hr/>
            <p align="center" class="alert alert-info">
            Tüm bankaları ve ödeme sistemlerini birlikte çalışacak şekilde (hibrit) kullanabilirsiniz.
            Örnek: Tüm kartların tek çekimlerini Xbankası üzerinden, 5 taksitli ödemeleri Ypay ödeme 
            kuruluşu üzerinden, ABC kartının 2 taksitli ödemelerini Zpara ödeme kuruluşu üzerinden tahsil edebilirsiniz.						
            Kart türlerine ödeme yönetiminin nasıl çalışacağını seçmek için 
            <a href="#cards" role="tab" data-toggle="tab">Taksitler</a> tıklayınız.
            </p>
			</div>
                    ';

		foreach (EticGateway::$gateways as $k => $gw) {
			$gw->is_bank = isset($gw->is_bank) && $gw->is_bank ? true : false;
			$gw->lib = isset($gw->lib) && $gw->lib ? $gw->lib : $k;
			$gw->eticsoft = isset($gw->eticsoft) && $gw->eticsoft ? true : false;

			$t .= '<div class="col-md-3 text-center panel">
                  <div class="panel-heading">' . $gw->full_name . '</div>';

			$t .= '<div class="panel-body spph250">';
			$t .= '<img src="' . plugins_url() . '/payu/img/gateways/' . $k . '.png" class="thumbnail center-block "/>';

			if (!$gw->active):
				$t .= '<p align="center" class="alert alert-danger">Bu entegrasyon geçici olarak aktif değil</p>';
			else :
				if ($gw->eticsoft)
					$t .= '<p align="center" class="alert alert-success"> EticSoft ' . ($k == 'onlineodemesistemi' ? ' tarafından geliştirilmiş arge ürünü yazılımdır' : 'resmi iş ortağıdır.') . '</p>';
				else
				if (!$gw->is_bank)
					$t .= '<p align="center" class="alert alert-danger"> EticSoft iş ortağı DEĞİLDİR. Teknik destekte kısıtlamalar olabilir. </p>';
			endif;
			$t .= ' <a href="https://payu.com/wordpress/' . $k . '-sanal-pos-kurulumu/" target="_blank" class="label label-default"><i class="icon-question"></i> Yardım</a>';
			if (json_decode($gw->families)):
				$t .= '<div style="line-height:25px"> <span>Taksit yapabildiği kartlar:</span>';
				foreach (json_decode($gw->families) as $family):
					$t .= ' <span class="label label-info">' . ucfirst($family) . '</span>';
				endforeach;
				$t .= '</div>';
			endif;
			$t .= '</div>';

			$t .= '<div class="panel-footer">';
			if ($gw->active):

				if (in_array($k, $exists_gws)):
					$t .= '<p align="center" class="alert alert-success"> Kurulu !</p>';
				else:
					$t .= '<span class="spr_price">' . ($gw->price == 0 ? 'Ücretsiz' : number_format($gw->price, 2) . ' TL/yıllık') . '</span><br/>';
					if (isset($gw->paid) AND $gw->paid):
						$t .= ' <form action="" method="post">'
							. '<input type="hidden" name="add_new_pos" value="' . $k . '"/>'
							. '<button type="submit" class="btn btn-success"><i class="icon-plus"></i> Kurulum </button>';
						$t .= wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . '</form>';
					else:
						$t .= EticConfig::getApiForm(array('redirect' => '?controller=gateway&action=buy&gateway=' . $k));
					endif;
				endif;

			endif;
			$t .= '</div></div>';
		}
		$t .= '
            </div>
            </div>';

		return $t;
	}

	public static function getApiForm($custom_array = false, $button_content = '<i class="icon-shopping-cart"></i> Satın Al')
	{
		$api = New SanalPosApiClient(1);
		$apilogininfo = $api->getLoginFormValues();
		$t = '<form action="' . $apilogininfo['url'] . '" target="_blank" method="post">';
		foreach ($apilogininfo as $k => $v)
			$t .= '<input type="hidden" name="' . $k . '" value="' . $v . '" />';
		if ($custom_array AND is_array($custom_array))
			foreach ($custom_array as $k => $v)
				$t .= '<input type="hidden" name="' . $k . '" value="' . $v . '" />';
		$t .= '<input type="hidden" name="api_login" value="1">'
			. '<button type="submit" class="btn btn-info">' . $button_content . '</button>'
			. wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . ' </form>';
		return $t;
	}

	public static function getAdminToolsForm()
	{

		$t = '<form action="#tools" method="post" id="toolsform">

            <div class="panel">
            <div class="row">';
		$t .= '
			<div class="col-md-4 sppbox bgred spph300"> <!--required for floating -->
            <h2>Eski Kayıtları Temizle</h2>
            <p>PayU! üzerinden yapılan alışveriş işlemlerinin tüm detaylarını, banka sorgu ve cevaplarını veri tabanına kayıt eder. (Kredi kartı bilgileri kayıt edilmez.)
            Bu bilgileri banka kayıtlarındaki uyumsuzluklarla karşılaştırmak, hata ayıklamak ve olası hukuki ihtilaflarda resmi mercilere sunmak için sizin sisteminize kayıt ediyoruz.
            Veritabanınızda çok fazla veri biriktiğinde bu bilgileri zaman zaman temizleyebilirsiniz. Bu temizleme işlemi son bir ay işlemleri hariç tüm işlemlerin detaylarını <b>geri getirilemeyecek şekilde</b> siler.</p>
            <hr/>
            <button class="btn btn-large btn-warning" name="clear-logs" value="1">Eski logları temizle</button>
            </div>';
		$t .= '
            <div class="col-md-4 text-center sppbox bgpurple spph300">
            <h2>Sunucu Uyumluluk Testi</h2>
            <p>
            Pos ve ödeme kuruluşlarının sistemleri bazı özel gereksinimlere ihtiyaç duyar. Bu gereksinimleri ve sisteminizin uyumluluğunu kontrol etmek için aşağıdaki aracı kullanabilirsiniz.
            Bu araç ayrıca PayU! modülünün çalışmasına engel olacak/etkileyecek modülleri/eklentileri de listeler.</p>
            <hr/>
            <button class="btn btn-large btn-success" name="check-server" value="1">Sunucuyu ve sistemi kontrol et</button>
            <br/>
            <br/>
            </div>';
		$t .= '
            <div class="col-md-4 text-center sppbox bgyellow spph300">
            <h2>Eski Versiyon Ayarları</h2>
            <p>
			Daha önce bir PayU! versiyonu kullandıysanız daha önce girilen banka parametrelerini göstermek için aşağıdaki butona tıklayabilirsiniz.
            Bu araç daha önceki versiyonlarda kurulu bankaları ve bilgilerini listeler. </p>
            <hr/>
            <button class="btn btn-large btn-info" name="check-oldtables" value="1">Eski bankaları göster</button>
            <br/>
            <br/>
            </div>';
		$t .= '</div>'; // Row
		/*
		  $cats = New HelperTreeCategoriesCore(1);
		  $cats->setUseCheckBox(true);
		  $cats->setTitle('Taksit uygulanmayacak kategoriler');
		  $cats->setInputName('spr_config_res_cats');

		  if (is_array(EticConfig::getResCats()))
		  $cats->setSelectedCategories(EticConfig::getResCats());
		  $t .= '<div class="row">';

		  $t .= '
		  <div class="col-md-6 panel">
		  <h2>Taksit Kısıtlaması</h2>
		  <p> Taksit yapılmayacak ürünlerin kategorilerini seçiniz.
		  Alışveriş sepetinde bu kategorilerden ürünler varsa taksitli alışveriş yapılmayacak,
		  ödemeler tek çekim olarak yapılabilecektir. Taksit kısıtlaması olan ürünler
		  sepete atıldığında müşteriye bir uyarı mesajı gösterilmektedir.
		  <b>Taksit kısıtlaması olan ürünleriniz yoksa hiç bir kategoriyi seçmeyiniz !</b>
		  </p>
		  ' . $cats->render() . '
		  <button type="submit" name="savetoolsform" value="1" class="btn btn-default pull-right"><i class="process-icon-save"></i> Kısıtlamaları Kaydet</button>
		  </div>';

		  $t .= '<div class="col-md-6 bgblue sppbox">'
		  . '<h2>FP007 Dolandırıcılık Koruma Sistemi</h2>'
		  . '<div class="alert alert-info">PayU! mağazalarının alışveriş süreçlerini güvenli hale getiren'
		  . 'FP007 proje kodlu yazılım servisimiz henüz yapım aşamasında !</div>'
		  . '<hr>'
		  . '</div>';
		  $t .= '</div>'; // Row

		 */
		$t .= '</div>'; // Panel



		$t .= wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . '</form>  ';
		return $t;
	}

	public static function getApiSettingsForm()
	{

		$t = '<form action="#tools" method="post" id="toolsform">

            <div class="panel">
            <div class="row">
            <div class="col-md-12 sppbox bgred"> <!--required for floating -->
            <h2>Eski Kayıtları Temizle</h2>
            <p>PayU! üzerinden yapılan alışveriş işlemlerinin tüm detaylarını, banka sorgu ve cevaplarını veri tabanına kayıt eder. (Kredi kartı bilgileri kayıt edilmez.)
            Bu bilgileri banka kayıtlarındaki uyumsuzluklarla karşılaştırmak, hata ayıklamak ve olası hukuki ihtilaflarda resmi mercilere sunmak için sizin sisteminize kayıt ediyoruz.
            Veritabanınızda çok fazla veri biriktiğinde bu bilgileri zaman zaman temizleyebilirsiniz. Bu temizleme işlemi son bir ay işlemleri hariç tüm işlemlerin detaylarını <b>geri getirilemeyecek şekilde</b> siler.</p>
            <hr/>
            <button class="btn btn-large btn-warning" name="clear-logs" value="1">Eski logları temizle</button>
            </div>
            <div class="col-md-6 text-center sppbox bgpurple">
            <h2>Sunucu Uyumluluk Testi</h2>
            <p>
            Pos ve ödeme kuruluşlarının sistemleri bazı özel gereksinimlere ihtiyaç duyar. Bu gereksinimleri ve sisteminizin uyumluluğunu kontrol etmek için aşağıdaki aracı kullanabilirsiniz.
            Bu araç ayrıca PayU!modülünün çalışmasına engel olacak/etkileyecek modülleri/eklentileri de listeler.</p>
            <hr/>
            <button class="btn btn-large btn-warning" name="check-server" value="1">Sunucuyu ve sistemi kontrol et</button>
            <br/>
            <br/>
            </div>
            </div>
            </div>
			' . wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . '
            </form> 
        ';
		return $t;
	}

	public static function getCardSettingsForm($module_dir)
	{
		$all_gws = EticGateway::getGateways(true);
		$def_rate = EticInstallment::getDefaultRate();


		$gateway = new EticGateway('payu');			
		$rates = EticTools::curlGet('https://secure.payu.com.tr/openpayu/v2/installment_payment.json/get_available_installments/'.$gateway->params->payu_merchant);
		if(!$gateway->params->payu_merchant OR !$rates) {
			return Etictools::rwm('<br/><h2>Taksitler Alınamadı </h2><hr/>
			Payu mağaza adını (Entegrasyon ismi) alanını boş veya geçerli olmadığı için taksit oranlarınız otomatik alınamadı. Lütfen pos ayarları alanından kontrol ediniz.');
		}
		
		
		
		$arates = json_decode($rates);
		if(!isset($arates->value)){
			return Etictools::rwm('<br/><h2>Taksitler Alınamadı </h2><hr/>
			Payu mağaza adını (Entegrasyon ismi) alanını boş veya geçerli olmadığı için taksit oranlarınız otomatik alınamadı. Lütfen pos ayarları alanından kontrol ediniz.');
		}
			
		foreach ($arates->value as $k => $rate){

			foreach ($rate as $i => $ins) {
				$inst = array();
				EticInstallment::delete($k);
				
				$post = Etictools::getValue($k);
				
				$inst['gateway'] = $gateway->name;
				$inst['divisor'] = $i;
				$inst['family'] = $k;
				$inst['fee'] = isset($post[$i]['fee']) ? $post[$i]['fee'] : null;
				$inst['rate'] = $ins->percent;
				EticInstallment::save($inst);
			}
		}

		Etictools::rwm(date("Y-m-d H:i:s").' itibariyle taksitler oranları PayU hesabınızdan otomatik güncellendi.' , true, 'success');
		Etictools::rwm('Müşterilerinize yansıyacak taksit oranlarınızı PayU hesabınızdan görüntüleyebilir veya değiştirebilirsiniz. <br/>
		Müşteri oranlarınız aşağıdaki tabloya otomatik olarak yansımaktadır. Sizden kesilecek oranları ise manuel girmelisiniz.', true, 'info');
		
		
		$t = '<form action="#cards" id="cards" method="post"> 
                <div class="panel">
				<div class="row ">
                    <div class="col-md-4"> <!-- required for floating -->
                        <h2>Kartlar ve taksit seçenekleri</h2>
                    </div>
                    <div class="col-md-8"> 
                        <a class="btn btn-default pull-right" href="#help" role="tab" data-toggle="tab"><i class="process-icon-help"></i> Yardım</a> 
                        <button type="submit" name="submitcards" class="btn btn-default pull-right"><i class="process-icon-save"></i> Oranları Kaydet</button>
                        <input type="hidden" name="submitcardrates" value="1"/>
                    </div>
                </div>';



		$t .= '<div class="row">';
		foreach (EticConfig::$families as $family):
			$gwas = EticGateway::getByFamily($family, true);

			$t .= '<div class="col-md-4 sppbox spph750"><br/>'
				. '<img src="' . plugins_url() . '/payu/img/cards/' . $family . '.png" class="thumbnail center-block"/><br/>';
			if (!$gwas OR empty($gwas)) {
				$t .= '<h2>Uygun POS Yok veya Kurulmamış</h2>'
					. '<p><i style="font-size: 45px;" class="icon-remove"></i></p>' . ucfirst($family) . ' kart ailesine taksit yapabileceğiniz'
					. ' hiç bir POS sistemi kurulu değil. ' . ucfirst($family) . ' ödemelerini taksitsiz olarak alabilirsiniz.<br/>'
					. '<div class="alert alert-info">Sadece Tek Çekim Ödeme alabilirsiniz. Tek Çekimler için '
					. 'tanımlanmış POS sistemi: ' . ucfirst($def_rate['gateway']) . ' </div>';
				$t .= '<div style="line-height:25px"> <h2>Taksit yapabilen pos sistemleri</h2>';
				foreach (EticGateway::getByFamily($family, false) as $gwall)
					$t .= ' <span class="label label-info">' . ucfirst(EticGateway::$gateways->{$gwall}->full_name) . '</span>';
				$t .= '</div></div>';
				continue;
			}

			$t .= '<div class="row"><div class="col-sm-6 col-xs-6">'
				. 'Tümü için toplu seçim </div>'
				. '<div class="col-sm-6 col-xs-6">'
				. '<select class="inst_select_all" id="' . $family . '" name="' . $family . '_all">'
				. '<option value="">Seçiniz</option>'
				. '<option value="0">Taksit Yok</option>';

			foreach ($gwas as $gwa)
				$t .= '<option value="' . $gwa . '">' . ucfirst(EticGateway::$gateways->{$gwa}->full_name) . '</option>';

			$t .= '</select></div></div>'
				. '<table class="table">'
				. '<tr>'
				. '<td>Taksit</td>'
				. '<td>Pos</td>'
				. '<td>Oran (%)<br/><small>Müşteriye<br/> yansıyacak</small></td>'
				. '<td>Maliyet (%)<br/><small>Sizden <br/> kesilecek</small></td>'
				. '</tr>';
			for ($i = 2; $i <= 12; $i++) :
				$ins = EticInstallment::getByFamily($family, $i);

				$t .= '<tr>'
					. '<td>' . $i . '</td>'
					. '<td><select class="inst_select ' . $family . ' form-control" id="row_' . $family . '_' . $i . '" name="' . $family . '[' . $i . '][gateway]">'
					. '<option value="0">Kapalı</option>';

				if ($i == 1) {
					$t .= '<option value="' . $def_rate['gateway'] . '">' . ucfirst($def_rate['gateway']) . ''
						. '(Varsayılan)</option>';
					foreach ($all_gws as $gwa)
						$t .= '<option ' . ($ins && $ins['gateway'] == $gwa->name ? 'selected ' : '')
							. 'value="' . $gwa->name . '">' . ucfirst($gwa->name) . '</option>';
				} else
					foreach ($gwas as $gwa)
						$t .= '<option ' . ($ins && $ins['gateway'] == $gwa ? 'selected ' : '')
							. 'value="' . $gwa . '">' . ucfirst(EticGateway::$gateways->{$gwa}->name) . '</option>';

				$t .= '</select></td>'
					. '<td><div class="input-group">' . ($ins ? '<span class="row_' . $family . '_' . $i . ' input-group-addon">%</span>' : '' )
					. '<input disabled class="form-control row_' . $family . '_' . $i . '  input_' . $family . '" size="5" step="0.01" type="number" style="width:60px" '
					. 'name="' . $family . '[' . $i . '][rate]" value="' . ($ins ? (float) $ins['rate'] : '') . '">'
					. '</div></td>'
					. '<td><div class="input-group' . ($ins['fee'] == 0 ? ' has-error' : '') . '">'
					. ($ins ? '<span class="row_' . $family . '_' . $i . ' input-group-addon">%</span>' : '' )
					. '<input type="number" step="0.01" style="width:60px" class="form-control row_' . $family . '_' . $i . ' input_' . $family . '"'
					. ' name="' . $family . '[' . $i . '][fee]" value="' . ($ins ? (float) $ins['fee'] : '') . '">'
					. '</div></td>'
					. '</tr>';
			endfor;

			$t .= '</table>';
			$t .= '<div style="line-height:25px"><span>';
			// foreach (EticGateway::getByFamily($family, false) as $gwall) değişti
			// 	$t .= ' <span class="label label-' . (in_array($gwall, $gwas) ? 'success' : 'default') . '">'
			// 		. '' . ucfirst(EticGateway::$gateways->{$gwall}->name) . '</span>';
			$t .= '</div>';
			$t .= '</div>';
		endforeach;
		$t .= '<div class="clear clearfix"></div>
            </div></div>
			' . wp_nonce_field('woocommerce-settings', '_wpnonce', true, false) . '
            </form>';
		return $t;
	}

	public static function getHelpForm()
	{

		$t = '
		<div class="panel">
			<div class="row">
				<div class="col-sm-6 text-center">
					<h1>PayU Türkiye bir tık uzağınızda</h1>
					<div class="row">
						<div class="col-sm-2"></div>
						<a href="https://www.payu.com.tr/destek" target="_blank">
							<img src="' . plugins_url() . '/payu/img/payu.png" style="height: 300px;" class="img-responsive text-center" id="payment-logoh" />
						</a>
						<div class="col-sm-2"></div>
					</div>
				</div>
				<div class="col-sm-6 panel text-center">

					<a href="https://secure.payu.com.tr/cpanel/" class="btn btn-info btn-large"><i class="icon icon-book"> </i> Destek Sistemine Bağlan</a> <hr/>
					<a href="mailto:destek@payu.com.tr?Subject=Woocommerce Payu "
					   class="btn btn-info btn-large"><i class="icon icon-mail-reply"> </i> E-posta destek@payu.com.tr</a>
					<hr/>
					<a class="btn btn-info btn-large"><i class="icon icon-phone"> </i> Telefon 0212 900 37 11</a>
				</div>

				<hr/>
			</div>
		</div>
		';
		return $t;
	}

	public static function saveCardSettingsForm()
	{
		foreach (EticConfig::$families as $family) {

			if (!Etictools::getValue($family) OR ! is_array(Etictools::getValue($family)))
				continue;
			$installments = Etictools::getValue($family);
			foreach ($installments as $i => $ins) {
				if ($ins['gateway'] == '0') {
					EticInstallment::deletebyFamily($family, $i);
					continue;
				}
				$ins['divisor'] = $i;
				$ins['family'] = $family;
				EticInstallment::save($ins);
			}
		}
		Etictools::rwm('Taksitler Güncellendi !', true, 'success');
	}

	public static function saveToolsForm()
	{
		if (Etictools::getValue('check-oldtables')) {
			if (EticSql::tableExists('spr_bank')) {
				$old_banks = EticSql::getRows('spr_bank');
				if ($old_banks) {
					$old_txt = '';
					foreach ($old_banks as $old_bank) {
						$params = unserialize($old_bank['params']);
						$old_txt .= '<hr/><b>' . $old_bank['ad'] . '</b> Parametreler <br/>';
						foreach ($params['params'] as $k => $v)
							$old_txt .= $k . ' : ' . $v['value'] . '</br>';
					}
					Etictools::rwm('Eski versiyona ait bankalar ' . $old_txt, true, 'success');
				}
			}
			Etictools::rwm('Eski versiyona ait bilgi bulunamadı', true, 'warning');
		} else {
			if (!Etictools::getValue('spr_config_res_cats') OR ! is_array(Etictools::getValue('spr_config_res_cats')))
				Eticconfig::set('SPR_RES_CATS', 'off');
			else
				Eticconfig::set('SPR_RES_CATS', json_encode(Etictools::getValue('spr_config_res_cats')));
			Etictools::rwm('Taksit Kısıtlamaları Güncellendi !', true, 'success');
		}
	}

	public static function saveGatewaySettings()
	{
		if (Etictools::getValue('remove_pos')) {
			$gw = New EticGateway(Etictools::getValue('remove_pos'));
			$gw->delete();
		}

		foreach (EticGateway::getGateways() as $gw) {
			if (Etictools::getValue('submit_for') AND Etictools::getValue('submit_for') != $gw->name)
				continue;
			$data = Etictools::getValue($gw->name);
			if (isset($data['lib']))
				$gw->lib = $data['lib'];
			$lib = EticGateway::$api_libs->{$gw->lib};
			if (!$lib OR ! $data) {
				Etictools::rwm($gw->name . ' Güncelleme hatası tespit edildi. Lütfen formu gözden geçiriniz ' . $gw->lib, true, 'fail');
				continue;
			}
			foreach ($lib->params as $pk => $pv)
				if (isset($data['params'][$pk]))
					$gw->params->{$pk} = $data['params'][$pk];
			$gw->test_mode = isset($data['test_mode']) ? $data['test_mode'] : false;
			if ($gw->save())
				Etictools::rwm($gw->full_name . ' güncellendi', true, 'success');
		}
	}

	public static function saveGeneralSettings()
	{
		//Change stage needs refresh token
		if (isset(EticTools::getValue('spr_config')['MASTERPASS_STAGE']))
			if (EticConfig::get('MASTERPASS_STAGE') != EticTools::getValue('spr_config')['MASTERPASS_STAGE'])
				EticConfig::set('MASTERPASS_LAST_KEYGEN', 0);
		if ($spr_config = EticTools::getValue('spr_config'))
			foreach ($spr_config as $k => $v)
				Eticconfig::set($k, $v);

		EticSql::updateRow('spr_installment', array(
			'rate' => Etictools::getValue('spr_config_default_rate'),
			'fee' => Etictools::getValue('spr_config_default_fee'),
			'gateway' => Etictools::getValue('spr_config_default_gateway')
			), array('family' => 'all'));
	}

	public static function getConfigNotifications()
	{
		//Check
		foreach (EticGateway::getGateways(true) as $gw) {
			if (isset($gw->params->test_mode) && $gw->params->test_mode == 'on')
				Etictools::rwm($gw->full_name . ' <strong>Test Modunda Çalışıyor</strong>');
		}
		if (EticSql::getRow('spr_installment', 'fee', 0)) {
			Etictools::rwm('Taksit tablosundaki maliyetler (Sizden kesilecek oranlar) eksik girilmiş.'
				. '<br/>Bu durum hesaplamada hatalara neden olabilir.');
		}
	}

	public static function cleardebuglogs()
	{
		return EticSql::deleteRows('spr_debug');
	}

	public static function testSys()
	{
		return true;
	}

	public static function getResCats()
	{
		return json_decode(EticConfig::get('SPR_RES_CATS'));
	}

	public static function displayError($body, $title = 'Hata !')
	{
		return '<div class="alert alert-danger"><h2>' . $title . '</h2>' . $body . '</div>';
	}
}
