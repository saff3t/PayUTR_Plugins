<?php
class Eticfamily
{
    public $name;
    public $version = 0.1;
    public static $families = array(
        'axess', 'bonus', 'world', 'paraf', 'advantage', 'maximum'
    );
    
    
}
