<?php

/**
 * WHMCS Ipara Gateway Module
 * **
 * LÜTFEN ÖNCELİKLE README DOSYASINI OKUYUNUZ
 * **
 * Bu eklenti WHMCS sistemleri üzerinden Kredi Kartı ödemeleri almanızı sağlar.
 * Tamamen açık kaynaklı ve ücretsizdir. Satılamaz. 
 * @copyright Copyright (c) PayU Ödeme Kuruluşu A.Ş
 * @license GPL http://www.gnu.org/licenses/gpl-3.0.en.html
 * @see http://payu.com.tr
 * @see http://docs.whmcs.com/Gateway_Module_Developer_Docs
 * Teknik destek için http://eticsoft.com.tr
 *
 */
if (!defined("WHMCS")) {
	die("This file cannot be accessed directly");
}

function eticsoft_payu_MetaData()
{
	return array(
		'DisplayName' => 'PayU Credit Card Gateway Module',
		'APIVersion' => '1.1', // Use API Version 1.1
		'DisableLocalCredtCardInput' => false,
		'TokenisedStorage' => false,
	);
}

function eticsoft_payu_getParams()
{
	$table = "tblpaymentgateways";
	$fields = "setting,value";
	$where = array("gateway" => 'eticsoft_payu');
	$query = select_query($table, $fields, $where);
	$params = array();
	while ($param = mysql_fetch_array($query)) {
		$params[$param['setting']] = $param['value'];
	}
	return $params;
}

function eticsoft_payu_config()
{
	$config_options = array(
		// the friendly display name for a payment gateway should be
		// defined here for backwards compatibility
		'FriendlyName' => array(
			'Type' => 'System',
			'Value' => 'PayU Kredi Kartı İle Ödeme Modülü',
		),
		// a text field type allows for single line text input
		'payu_merchant' => array(
			'FriendlyName' => 'Mağaza entegrasyon ismi',
			'Type' => 'text',
			'Size' => '25',
			'Default' => '',
			'Description' => 'Mağaza entegrasyon ismi değerini PayU hesabınızdan (payu.com) edinebilirsiniz.',
		),
		// a password field type allows for masked text input
		'payu_key' => array(
			'FriendlyName' => 'Kodlama Anahtarı Anahtar (Secret Key)',
			'Type' => 'text',
			'Size' => '60',
			'Default' => '',
			'Description' => 'Mağaza entegrasyon ismi değerini PayU hesabınızdan (payu.com) edinebilirsiniz.',
		),
		'payu_installment' => array(
			'FriendlyName' => 'Taksit Seçenekleri',
			'Type' => 'dropdown',
			'Options' => array(
				'on' => 'Taksit Seçenekleri Sun',
				'off' => 'Tüm ödemeleri tek çekim ile yaptır.',
			),
			'Description' => 'Taksitli alışveriş',
		),
	);
	return $config_options;
}


function eticsoft_payu_validate3d($params)
{	
	$record = array(
		'id_cart' => $params['invoice']['id'],
		'id_customer' => $params['invoice']['clientdetails']['userid'],
		'amount_paid' => 0,
		'result' => false
	);

		if (!EticTools::getValue('HASH')) {
			$tr->result = false;
			$record['result_code'] = 'INTHV';
			$record['result_message'] = 'NO POST[HASH] HERE';
			return $record;
		}

		//begin HASH verification
		$arParams = $_POST;
		unset($arParams['HASH']);

		$hashString = "";
		foreach ($arParams as $val)
			$hashString .= strlen($val) . $val;

		$secretKey = $params['payu_key'];
		$expectedHash = hash_hmac("md5", $hashString, $secretKey);
		if ($expectedHash != $_POST["HASH"]) {
			$record['result_code'] = 'INTHV';
			$record['result_message'] = 'HASH MISSMATCHED';
			return $record;
		}
		$payuTranReference = $_POST['REFNO'];
		$amount = $_POST['AMOUNT'];
		$currency = $_POST['CURRENCY'];
		$installments_no = $_POST['INSTALLMENTS_NO'];

		if($_POST['STATUS'] == "SUCCESS")
			$record['result'] = $_POST['STATUS'] == "SUCCESS" ? true : false;

			$record['result_code'] = $_POST['RETURN_CODE'];
			$record['result_message'] = $_POST['RETURN_MESSAGE'];
		return $record;
}

function eticsoft_payu_capture($params)
{
	global $smarty;
	
	
	$_POST['payu_installment'] = isset($_POST['payu_installment']) ? (int)$_POST['payu_installment'] : 
	(isset($_SESSION['payu_installment']) ? (int)$_SESSION['payu_installment'] : 1);
	
	$response = eticsoft_payu_post2PayU($params);
	$smarty->assign('errormessage_payu', $response['result_code'] . ':' . $response['result_message']);

	return array(
		'status' => $response['result'] ? 'success' : 'declined',
		'rawdata' => $response,
		'transid' => $response['id_payu'],
		'fees' => $response['fee'],
		'errormessage' => $response['result_code'] . ':' . $response['result_message'],
		'error' => $response['result_code'] . ':' . $response['result_message'],
	);
}

function eticsoft_payu_post2PayU($params)
{

	$url = "https://secure.payu.com.tr/order/alu/v3";
	$secretKey = $params['payu_key'];
	$products_array = array();

	$arParams = array(
		"MERCHANT" => $params['payu_merchant'],
		"ORDER_REF" => 'WHMCS-' . $params['invoiceid'],
		"ORDER_DATE" => gmdate('Y-m-d H:i:s'),
		"PRICES_CURRENCY" => $params['currency'],
		"PAY_METHOD" => "CCVISAMC",
		"SELECTED_INSTALLMENTS_NUMBER" => isset($_POST['payu_installment']) ? (int) $_POST['payu_installment'] : 0,
		"CC_NUMBER" => $params['cardnum'],
		"EXP_MONTH" => substr($params['cardexp'], 0, 2),
		"EXP_YEAR" => substr($params['cardexp'], 2, 4),
		"CC_CVV" => $params['cccvv'],
		"CC_OWNER" => $params['clientdetails']['firstname'] . ' ' . $params['clientdetails']['lastname'],
		"BACK_REF" =>  $params['systemurl'] . '/creditcard.php?invoiceid=' . $params['invoiceid'] . '&tdvalidate=1',
		"CLIENT_IP" => $_SERVER['REMOTE_ADDR'],
		"BILL_LNAME" => $params['clientdetails']['firstname'],
		"BILL_FNAME" => $params['clientdetails']['lastname'],
		"BILL_EMAIL" => $params['clientdetails']['email'],
		"BILL_PHONE" => $params['clientdetails']['phone'],
		"BILL_COUNTRYCODE" => "TR",
		"BILL_ZIPCODE" => "", //optional
		"BILL_ADDRESS" => $params['clientdetails']['address1'],
		"BILL_ADDRESS2" => $params['clientdetails']['address2'],
		"BILL_CITY" => $params['clientdetails']['city'],
		"BILL_STATE" => 'TR',
		"BILL_FAX" => "", //optional
		"DELIVERY_LNAME" => $params['clientdetails']['firstname'], //optional
		"DELIVERY_FNAME" => $params['clientdetails']['last'], //optional
		"DELIVERY_EMAIL" => $params['clientdetails']['email'], //optional
		"DELIVERY_PHONE" => $params['clientdetails']['phone'], //optional
		"DELIVERY_COMPANY" => $params['clientdetails']['companyname'], //optional
		"DELIVERY_ADDRESS" => $params['clientdetails']['address1'], //optional
		"DELIVERY_ADDRESS2" => $params['clientdetails']['address2'],
		"DELIVERY_ZIPCODE" => "", //optional
		"DELIVERY_CITY" => $params['clientdetails']['city'],
		"DELIVERY_STATE" => "",
		"DELIVERY_COUNTRYCODE" => "TR", //optional
	);


	$i = 0;
		$arParams["ORDER_PNAME[" . $i . "]"] =  $params['description'];
		$arParams["ORDER_PCODE[" . $i . "]"] = $params['invoiceid'];
		$arParams["ORDER_PINFO[" . $i . "]"] = $params['description'];
		$arParams["ORDER_PRICE[" . $i . "]"] = $params['amount'];
		$arParams["ORDER_QTY[" . $i . "]"] = 1;


	ksort($arParams);
	$hashString = "";
	foreach ($arParams as $key => $val) {
		$hashString .= strlen($val) . $val;
	}

	$arParams["ORDER_HASH"] = hash_hmac("md5", $hashString, $secretKey);
	//end HASH calculation

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($arParams));
	$response = curl_exec($ch);
	
	unset($arParams['CC_CVV']);
	unset($arParams['CC_NUMBER']);
		// Gerekli değil gatewaylog için özel olarak yarattık
	$debug_array = array(
		'request_params' => $arParams,
		'response' => $response,
	);

	if (curl_errno($ch)) { // CURL HATASI
		$record['result_code'] = 'CURL-' . curl_errno($ch);
		$record['result_message'] = 'API Hatası ' . curl_error($ch);
		$record['result'] = false;
		return $record;	}

	if(!$parsedXML = simplexml_load_string($response)){ // OKUMA HATASI
		$record['result_code'] = 'APIXMLLOAD';
		$record['result_message'] = 'API Parse Hatası ';
		$record['result'] = false;
		return $record;	
	}

	if (($parsedXML->RETURN_CODE == "3DS_ENROLLED") && (!empty($parsedXML->URL_3DS))) {
		$tr->save();
		header("Location:" . $parsedXML->URL_3DS);
		die();
	}

	// print_r($parsedXML);
	// exit;
	
	$record['id_payu'] = $parsedXML->REFNO;
	$record['result_message'] = $parsedXML->RETURN_MESSAGE;
	$record['result'] = $parsedXML->STATUS == "SUCCESS" ? true : false;
	$record['amount_paid'] = $amount;
	return $record;
}

function eticsoft_payu_getAvailablePrograms()
{
	return array(
		'axess' => array('name' => 'Axess', 'bank' => 'Akbank A.Ş.'),
		'word' => array('name' => 'WordCard', 'bank' => 'Yapı Kredi Bankası'),
		'bonus' => array('name' => 'BonusCard', 'bank' => 'Garanti Bankası A.Ş.'),
		'cardfinans' => array('name' => 'CardFinans', 'bank' => 'FinansBank A.Ş.'),
		'asyacard' => array('name' => 'AsyaCard', 'bank' => 'BankAsya A.Ş.'),
		'maximum' => array('name' => 'Maximum', 'bank' => 'T.C. İş Bankası'),
		'paraf' => array('name' => 'Paraf', 'bank' => 'T Halk Bankası A.Ş.'),
		'advantage' => array('name' => 'Paraf', 'bank' => 'ING Bank'),
	);
}

function eticsoft_payu_calculatePrices($price, $rates)
{
	$banks = eticsoft_payu_getAvailablePrograms();
	for ($i = 1; $i <= 9; $i++) {
		$return[$i] = array(
			'total' => number_format((((100 + $rates[$i . '_installment']) * $price) / 100), 2, '.', ','),
			'monthly' => number_format((((100 + $rates[$i . '_installment']) * $price) / 100) / $i, 2, '.', ','),
		);
	}
	return $return;
}

function eticsoft_payu_installments_form($params, $amount)
{

	$amount = eticsoft_payu_getAmount($params['invoice']['balance']);
	$payu_params = eticsoft_payu_getParams();
	$rates = eticsoft_payu_calculatePrices($amount, $payu_params);

	$txt = 'Taksit Seçimi: <select name="payu_installment" class="select">';
	for ($ins = 1; $ins < 9; $ins++)
		if ($ins == 1)
			$txt .= '<option value="' . $ins . '">Tek Çekim'
					. ' ' . $rates[key($rates)]['installments'][$ins]['total'] . '</option>';
		else
			$txt .= '<option value="' . $ins . '">' . $ins . ' taksit X ' . $rates[key($rates)]['installments'][$ins]['monthly']
					. ' = ' . $rates[key($rates)]['installments'][$ins]['total'] . '</option>';
	$txt .= '</select>';

	return $txt;
}

add_hook('ClientAreaPageCreditCardCheckout', 1, function($vars) {
	$errormessage_payu = false;
	if (isset($_GET['tdvalidate']) AND $_GET['tdvalidate']) {
		$record = eticsoft_payu_validate3d($vars);
		$errormessage_payu = 'Hata: ('.$record['result_code'].') '.$record['result_message'];
			
			$result = $record['result'] ? 'success' : 'declined';
			
			logTransaction( 
				'eticsoft_payu', 
				$record, 
				$result 
			); 
		if($record['result']) {
			$fee = (float)($record['amount']-(eticsoft_payu_getAmount($vars['invoice']['balance'])));
			addInvoicePayment( 
				$vars['invoice']['id'], 
				$record['orderId'], 
				eticsoft_payu_getAmount($vars['invoice']['balance']), 
				$fee, 
				'eticsoft_payu' 
			);
			redir("id=" . $vars['invoice']['id'], "viewinvoice.php");

		}
	}
	$amount = eticsoft_payu_getAmount($vars['invoice']['balance']);
	$payu_params = eticsoft_payu_getParams();
	return array(
		"pagetitle" => $vars['filename'],
		"installments" => eticsoft_payu_calculatePrices($amount, $payu_params),
		"errormessage_payu" => $errormessage_payu
	);
	
}
);

add_hook('ClientAreaPageCart', 1, function($vars) {
/* 	if ($_GET['a'] != "checkout")
		return;
 */	$amount = eticsoft_payu_getAmount($vars['total']);
	$payu_params = eticsoft_payu_getParams();
	return array(
		"installments" => eticsoft_payu_calculatePrices($amount, $payu_params),
		"payu_currency" => preg_replace("/[^a-zA-Z]+/", "", $vars['total'])
	);
}
);

add_hook('ShoppingCartValidateCheckout', 1, function($vars) {
		if(isset($_POST['payu_installment'])) {
			$_SESSION['payu_installment'] = (int)$_POST['payu_installment'];
		}
	}
);


function eticsoft_payu_getAmount($money)
{
	$cleanString = preg_replace('/([^0-9\.,])/i', '', $money);
	$onlyNumbersString = preg_replace('/([^0-9])/i', '', $money);

	$separatorsCountToBeErased = strlen($cleanString) - strlen($onlyNumbersString) - 1;

	$stringWithCommaOrDot = preg_replace('/([,\.])/', '', $cleanString, $separatorsCountToBeErased);
	$removedThousendSeparator = preg_replace('/(\.|,)(?=[0-9]{3,}$)/', '', $stringWithCommaOrDot);

	return (float) str_replace(',', '.', $removedThousendSeparator);
}
