<?php
// Heading
$_['heading_title']				= 'PayU SanalPos Ayarları';

// Text
$_['text_payment']       = 'Ödeme Metodları';
$_['text_success']       = 'Başarılı: PayU SanalPos Bilgileriniz Güncellendi!';
$_['text_edit']          = 'PayU SanalPos Entegrasyon Bilgileriniz';
$_['text_payu']          = '<a href="http://payu.com.tr/" target="_blank"><img src="../catalog/view/theme/default/image/payu/logo.png" alt="PayU SanalPos" title="PayU SanalPos" style="border: 1px solid #EEEEEE;" /></a>';
