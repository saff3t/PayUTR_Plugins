# OpenCart PayU SanalPOS Eklentisi 

Powered by [EticSoft](https://eticsoft.com) - EticSoft R&D Lab.

> Bu eklenti PayU �deme Kurulusu A.S. ile EticSoft arasindaki isbirligine istinaden EticSoft tarafindan gelistirilmistir. 

> Bu eklenti OpenCart 3.0 ve �zeri versiyonlar ile tam uyumludur. 3.0 altindaki versiyonlarda test edilmemistir. 

PayU SanalPOS eklentisi Opencart e-ticaret sisteminize PayU sanalPOS entegrasyonunu saglar. Bu eklenti ile m�sterileriniz magazanizdan kredi kartlari ile alisveris yapabilirler. 

  - Tamamen �cretsizdir ve a�ik kaynak kodludur.
  - Hi� bir kod modifikasyonu istemez. Kurulum ve kaldirma islemleri basittir.
  - T�m kredi kartlarindan �deme alir.
  - �demenin g�venli ve kolay olmasini saglar.
  - Hi� bir teknik bilgi istemeden kolayca kurulur ve kaldirilir.

# Kullanim Sartlari

  - PayU mod�l� PayU �deme Kurulusu A.S tarafindan GPL lisansi ile a�ik kaynakli ve �cretsiz sunulmaktadir. Satilamaz.
  - PayU mod�l� PayU �deme Kurulusu A.S 'nin sagladigi servisleri kullanmak i�in gelistirilmistir. Baska ama�la kullanilamaz.
  - Uluslararasi kabul g�rm�s g�venlik standartlarina g�re �deme yapilan kredi karti bilgilerine erisilmesi veya bilgilerin kayit edilmesi yasaktir. 
  - Bu eklenti orijinal kaynak kodlariyla m�sterilerinizin kredi karti bilgilerini siteminize veya herhangi bir yere asla kaydetmez. 
  - Kaynak kodlarini bu kurallara uygun tutmak sizin sorumlulugunuzdadir.
  - Eklentinin kurulu olacagi magazaya ait versiyon ve iletisim bilgileriniz (magaza eposta, OpenCart versiyonu v.b.) gelistirici teknik destek ve bilgilendirme sistemine otomatik kayit edilecek ve bu bilgiler �nemli bildirimler ile g�ncellemelerden haberdar olmaniz i�in kullanilacaktir.

# Kurulum 
  - FTP ile sitenize baglanin
  - Indirdiginiz zip dosyasini a�tiginizda iki klas�r g�receksiniz. admin ve catalog
  - Bu iki klas�r� FTP ile sitenizin ana dizinine atin.
  - Y�netim panelinize giris yapip eklentiler sekmesine tiklayin.
  - �deme y�ntemleri (payment) eklentilerinden PayU SanalPOS eklentisini kurun. 
  - Eklentinin ayarlar b�l�m�nden PayU hesap bilgilerini girin ve tercihlerinizi yapin. 
  - Magazanizin �n sayfasina giris yapip EN AZ BIR BASARILI �DEME YAPMAYI DENEYIN !

# Yardim 

* [PayU web](https://payu.com.tr) - PayU �deme Kurulusu A.S.
* [EticSoft web](https://eticsoft.com) - EticSoft R&D Lab.
* [EticSoft destek sistemi](https://eticsoft.com/support) - EticSoft R&D Lab.
* [Eklentiler](https://eticsoft.com/shop) - EticSoft Shop.
