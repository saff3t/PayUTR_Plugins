<?php

/* 
 */

include_once (dirname(__FILE__).'/Eticconfig.php');
include_once (dirname(__FILE__).'/Etictools.php');
include_once (dirname(__FILE__).'/Eticgateway.php');
include_once (dirname(__FILE__).'/Eticinstallment.php');
include_once (dirname(__FILE__).'/Eticsql.php');
include_once (dirname(__FILE__).'/Etictransaction.php');
include_once (dirname(__FILE__).'/SanalPosApiClient.php');
include_once (dirname(__FILE__).'/Eticstats.php');
include_once (dirname(__FILE__).'/EticUi.php');
include_once (dirname(__FILE__).'/EticUiOpencart.php');
include_once (dirname(__FILE__).'/EticPayuIpn.php');