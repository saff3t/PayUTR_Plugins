<?php
class EticPayuIpn
{
	
	public function run() {
		$hash = $this->checkHash($_POST);
		
		$tr = new EticTransaction();
		
		if(!$hash){
			$tr->result = false;
			$tr->result_message = 'Invalid Hash';
			$tr->result_code = 'IPNVAL_04';
			return $tr;
		}		
		

		if(!EticTools::getValue('REFNO')){
			$tr->result = false;
			$tr->result_message = 'Reference not found';
			$tr->result_code = 'IPNVAL_02';
			return $tr;
		}


		$tre = EticTransaction::getTransactionByBoId(EticTools::getValue('REFNO'));
		if($tre){
			return $tre;
		}	
		
		return false;

	}
	
	
	function responseIpn(){
		$file_name = date("Y-m-d_h-i-s").'_'.EticTools::getValue('REFNO').'.log';
		$requested = print_r($_POST, true);


		$date_return = date("YmdGis");

		$responsed = "<EPAYMENT>".$date_return."|".$result_hash."</EPAYMENT>";
		// $handle = fopen($file_name, "a");
		// if($handle){
			// fwrite($handle, $requested."\n\n".$responsed);
			// fclose($handle);
		// }
		echo $responsed;
	}


	public function checkHash(){
		if(!EticTools::getValue('HASH'))
			return false;
		/* Make sure strlen behaves as intended by setting multibyte function overload to 0*/
		ini_set("mbstring.func_overload", 0);
		if(ini_get("mbstring.func_overload") > 2)
		{  	/* check if mbstring.func_overload is still set to overload strings(2)*/
			echo "WARNING: mbstring.func_overload is set to overload strings and might cause problems\n";
		}

		$gw = new EticGateway('payu');

		$pass			= $gw->params->payu_key;	/* pass to compute HASH */
		$result			= ""; 				/* string for compute HASH for received data */
		$return			= ""; 				/* string to compute HASH for return result */
		$signature		= $_POST["HASH"];	/* HASH received */
		$body				= "";
		
		ob_start();
		while(list($key, $val) = each($_POST)){
			$$key=$val;
			/* get values */
			if($key != "HASH"){
				if(is_array($val)) $result .= $this->arrayExpand($val);
			else{
					$size		= strlen(StripSlashes($val));
					$result	.= $size.StripSlashes($val);
				}
			}
		}
		$body = ob_get_contents();
		ob_end_flush();

		$date_return = date("YmdGis");

		$return = strlen($_POST["IPN_PID"][0]).$_POST["IPN_PID"][0].strlen($_POST["IPN_PNAME"][0]).$_POST["IPN_PNAME"][0];
		$return .= strlen($_POST["IPN_DATE"]).$_POST["IPN_DATE"].strlen($date_return).$date_return;
		
		$hash =  $this->hmac($pass, $result); /* HASH for data received */
		$body .= "\n".$result."\r\n\r\nHash: ".$hash."\r\n\r\nSignature: ".$signature."\r\n\r\nReturnSTR: ".$return;
		

		$requested = print_r($_POST, true);

		$result_hash =  $this->hmac($pass, $return);
		
		$responsed = "<EPAYMENT>".$date_return."|".$result_hash."</EPAYMENT>";
		$file_name = dirname(__FILE__).'/'.date("Y-m-d_h-i-s").'_'.EticTools::getValue('REFNO').'.log';
		// $handle = fopen($file_name, "a");
		// if($handle){
			// fwrite($handle, $requested."\n\n".$responsed);
			// fclose($handle);
		// }
		echo $responsed;
		
		if($hash == $signature){
			return true;
		}
		
		return false;


	}

	public function ArrayExpand($array){
		$retval = "";
		for($i = 0; $i < sizeof($array); $i++){
			$size		= strlen(StripSlashes($array[$i]));
			$retval	.= $size.StripSlashes($array[$i]);
		}

		return $retval;
	}

	public function hmac ($key, $data){
		$b = 64; // byte length for md5
		if (strlen($key) > $b) {
			$key = pack("H*",md5($key));
		}
		$key  = str_pad($key, $b, chr(0x00));
		$ipad = str_pad('', $b, chr(0x36));
		$opad = str_pad('', $b, chr(0x5c));
		$k_ipad = $key ^ $ipad ;
		$k_opad = $key ^ $opad;
		return md5($k_opad  . pack("H*",md5($k_ipad . $data)));
	}

}