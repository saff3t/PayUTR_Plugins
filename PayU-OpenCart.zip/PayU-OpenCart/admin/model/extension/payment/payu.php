<?php 
class ModelExtensionPaymentPayu extends Model {
	public function install() {
		return true;
	}
}
