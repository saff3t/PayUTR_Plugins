<?php
if (!defined('ABSPATH'))
	exit;
include(dirname(__FILE__).'/EticsoftMasterPass.php');
include(dirname(__FILE__).'/EticsoftMasterTools.php');
include(dirname(__FILE__).'/EticsoftMasterPassJsApi.php');
include(dirname(__FILE__).'/EticsoftMasterPassGateway.php');