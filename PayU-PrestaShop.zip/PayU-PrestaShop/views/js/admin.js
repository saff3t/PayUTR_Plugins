/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(function () {
    var activeTab = $('[href=' + location.hash + ']');
    activeTab && activeTab.tab('show');
});
$(document).ready(function () {
    $("select.inst_select").change(function () {
        var cname = $(this).attr("id");
        if ($(this).val() == 0)
            $("." + cname).hide();
        else
            $("." + cname).show();
    });

    $("select.inst_select_all").change(function () {
        var cnameall = $(this).attr("id");
        if ($(this).val() == 0)
            $("select." + cnameall).val(0);
        else
            $("select." + cnameall).val($(this).val());
        $("select.inst_select").change();
    });
    $("select.inst_select").change();
});

