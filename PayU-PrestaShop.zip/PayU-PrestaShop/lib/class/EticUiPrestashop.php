<?php

class EticUiPrestashop extends EticUi
{

	function __construct($module = false)
	{
		$link = New Link();
		$shop = Context::getContext()->shop;
		$this->module = $module;
		if(!$module)
			$this->module = New Payu();

		$this->store_uri = $shop->getBaseURI();
		$this->store_url = 'https://' . $shop->domain_ssl . $this->store_uri;
		$this->uri = $this->store_uri . "modules/payu/";
		$this->url = $this->store_url . "modules/payu/";
	}

	public function l($txt, $specific = false, $source = 'eticui')
	{ // translate
		return TranslateCore::getModuleTranslation('payu', $txt, $source);
	}

	public function displayPrice($price, $currency = null)
	{
		return Tools::displayPrice($price, $currency);
	}

	public function addCSS($file, $external = false)
	{
		$this->context .= '
		<link rel="stylesheet" href="' . $this->uri . $file . '" type="text/css" media="all">';
	}
}
