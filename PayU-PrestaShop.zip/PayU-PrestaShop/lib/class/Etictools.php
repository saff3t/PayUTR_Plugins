<?php

class Etictools
{
	/* Return and Assign Message */

	public static function rwm($message, $return = false, $type = 'fail')
	{
		if ($type == 'fail' OR $type == 'error')
			$type = 'danger';
		EticConfig::$messages [] = array('message' => $message, 'type' => $type);
		return $return;
	}

	public static function getValue($key, $default_value = false)
	{
		if (!isset($key) || empty($key) || !is_string($key))
			return false;

		$ret = (isset($_POST[$key]) ? $_POST[$key] : (isset($_GET[$key]) ? $_GET[$key] : $default_value));

		if (is_string($ret))
			return stripslashes(urldecode(preg_replace('/((\%5C0+)|(\%00+))/i', '', urlencode($ret))));

		return $ret;
	}

	public static function getCustomerName($id_customer)
	{
		if ($customer = New CustomerCore((int) $id_customer) AND $customer->id) {
			return $customer->firstname . ' ' . $customer->lastname;
		}
		return "-";
	}

	public static function escape($string, $html_ok = false, $bq_sql = false)
	{
		$string = addslashes(stripslashes($string));

		if (!is_numeric($string)) {

			if (!$html_ok) {
				$string = strip_tags($string);
			}

			if ($bq_sql === true) {
				$string = str_replace('`', '\`', $string);
			}
		}
		return $string;
	}

	public static function fixTrUnigateway($q)
	{
		$q = str_replace("Ä°", "İ", $q);
		$q = str_replace("Ã§", "ç", $q);
		$q = str_replace("Å", "ş", $q);
		return $q;
	}

	public static function encodetxt($txt)
	{
		return addslashes($txt);
		return base64_engateway($txt);
	}

	public static function decodetxt($txt)
	{
		return $txt;
		return base64_degateway($txt);
	}

	public static function xml2array($xmlObject, $out = array())
	{
		foreach ((array) $xmlObject as $index => $node)
			$out[$index] = ( is_object($node) || is_array($node) ) ? $this->xml2array($node) : $node;

		return $out;
	}

	public static function generateKey($id, $dyn = true)
	{
		return md5($_SERVER['REMOTE_ADDR'] . $id . ($dyn ? date("md") : '') . $_SERVER['HTTP_HOST']);
	}

	public static function curlPostExt($data, $url, $json = false)
	{
		$ch = curl_init(); // initialize curl handle
		curl_setopt($ch, CURLOPT_URL, $url); // set url to post to
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // return into a variable
		if ($json)
			curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-type: application/json"));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); // times out after 4s
		curl_setopt($ch, CURLOPT_POST, 1); // set POST method
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // add POST fields
		if ($result = curl_exec($ch)) { // run the whole process
			curl_close($ch);
			return $result;
		}
		return false;
	}

	public static function curlGet($url = null)
	{
		$ch = curl_init(); // initialize curl handle
		curl_setopt($ch, CURLOPT_URL, $url);   // set url to gatewayt to
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // return into a variable
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); // times out after 4s
		if ($result = curl_exec($ch)) {  // run the whole process
			curl_close($ch);
			return $result;
		}
		return curl_error($ch);
	}

	public static function getTagValue($tag, $str)
	{
		$stag = "<" . $tag . ">";
		$etag = "</" . $tag . ">";
		$pop1 = explode($stag, $str);
		$pop2 = explode($etag, $pop1[1]);
		return $pop2[0];
	}

	public static function fixEncoding($in_str)
	{
		$from = array("/ Ğ/", "/Ü/ ", "/ Ş

            /", "/İ/", "/Ö/", "/Ç/", "/ğ/", "/ü/", "/ş/", "/ı/", "/ö/", "/ç/", '^');
		$to = array("G", "U", "S", "I", "O", "C", "g", "u", "s", "i", "o", "c", '');
		$in_str = str_replace($from, $to, $in_str);
		$cur_encoding = mb_detect_encoding($in_str);
		if ($cur_encoding == "UTF-8" && mb_check_encoding($in_str, "UTF-8"))
			return $in_str;
		return utf8_engateway($in_str);
	}

	public static function simpleXMLToArray($xml, $flattenValues = true, $flattenAttributes = true, $flattenChildren = true, $valueKey = '@value', $attributesKey = '@attributes', $childrenKey = '@children')
	{

		$return = array();
		if (!($xml instanceof SimpleXMLElement)) {
			return $return;
		}
		$name = $xml->getName();
		$_value = trim((string) $xml);
		if (strlen($_value) == 0) {
			$_value = null;
		};

		if ($_value !== null) {
			if (!$flattenValues) {
				$return[$valueKey] = $_value;
			} else {
				$return = $_value;
			}
		}

		$children = array();
		$first = true;
		foreach ($xml->children() as $elementName => $child) {
			$value = $this->simpleXMLToArray($child, $flattenValues, $flattenAttributes, $flattenChildren, $valueKey, $attributesKey, $childrenKey);
			if (isset($children[$elementName])) {
				if ($first) {


					$temp = $children[$elementName];
					unset($children[$elementName]);
					$children[$elementName][] = $temp;
					$first = false;
				}
				$children[$elementName][] = $value;
			} else {
				$children[$elementName] = $value;
			}
		}
		if (count($children) > 0) {
			if (!$flattenChildren) {
				$return[$childrenKey] = $children;
			} else {
				$return = array_merge($return, $children);
			}
		}

		$attributes = array();
		foreach ($xml->attributes() as $name => $value) {
			$attributes[$name] = trim($value);
		}
		if (count($attributes) > 0) {
			if (!$flattenAttributes) {
				$return[$attributesKey] = $attributes;
			} else {
				$return = array_merge($return, $attributes);
			}
		}

		return (object) $return;
	}

	public static function displayPrice($price)
	{
		return Tools::displayPrice($price);
	}

	public static function getIp()
	{
		if (function_exists('apache_request_headers')) {
			$headers = apache_request_headers();
		} else {
			$headers = $_SERVER;
		}

		if (array_key_exists('X-Forwarded-For', $headers)) {
			$_SERVER['HTTP_X_FORWARDED_FOR'] = $headers['X-Forwarded-For'];
		}

		if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && (!isset($_SERVER['REMOTE_ADDR']) || preg_match('/^127\..*/i', trim($_SERVER['REMOTE_ADDR'])) || preg_match('/^172\.16.*/i', trim($_SERVER['REMOTE_ADDR'])) || preg_match('/^192\.168\.*/i', trim($_SERVER['REMOTE_ADDR'])) || preg_match('/^10\..*/i', trim($_SERVER['REMOTE_ADDR'])))) {
			if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',')) {
				$ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
				return $ips[0];
			} else {
				return $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
		} else {
			return $_SERVER['REMOTE_ADDR'];
		}
	}

	public static function maskCcNo($ccno)
	{
		return substr((string) $ccno, 0, 6) . 'XXXXXXXX' . substr((string) $ccno, -2);
	}

	public static function isMobile($phone)
	{
		$numbers = Etictools::formatMobile($phone);
		return is_numeric($numbers) && substr($numbers, 2, 1) == 5;
	}

	public static function formatMobile($phone)
	{
		return '90' . substr(preg_replace('/[^0-9]/', '', $phone), -10);
		/*
		  Test $phones = array(
		  );
		  foreach($phones as $phone){
		  echo "<br/>".Etictools::formatMobile($phone);
		  var_dump(Etictools::isMobile($phone));
		  }
		 */
	}

	public static function removeBOM($data)
	{
		if (0 === strpos(bin2hex($data), 'efbbbf')) {
			return substr($data, 3);
		}
		return $data;
	}

	public static function recursive_array_search($needle, $haystack)
	{
		foreach ($haystack as $key => $value) {
			if ($needle === $value) {
				return array($key);
			} else if (is_array($value) && $subkey = Etictools::recursive_array_search($needle, $value)) {
				array_unshift($subkey, $key);
				return $subkey;
			}
		}
	}
}
