<?php

class EticUI
{

	public $url;
	public $uri;
	public $store_url;
	public $store_uri;
	public $path;
	public $store_path;
	public $js_dir;
	public $css_dir;
	public $force_bootstrap;
	public $force_jquery;
	public $module;
	public $context = '';

	public function display()
	{
		return $this->context;
	}

	public function displayAdminOrder($tr)
	{
		$currency = new Currency($tr->id_currency);
		$t = '
		<div class="eticsoft">
			<div class="col-md-6" >
				<div class="panel">
					<div class="panel-heading">
						<i class="icon-credit-card"></i>
						' . $this->l('Credit Card Process Details') . '
						<span class="badge">
							' . $tr->gateway . '#' . $tr->boid . '
						</span>
					</div>
					<table class="table">
						<tr>
							<td>' . $this->l('POS answer:') . '#' . $tr->result_code . ' ' . $tr->result_message . '<br/>
								' . $this->l('Date') . ' <span class="badge">' . $tr->date_update . '</span></td>
							<td><img src="' . $this->url . '/img/gateways/' . $tr->gateway . '.png" /></td>
						</tr>
						<tr>
							<td>' . $this->l('Total Amount') . '</td>
							<td><span style="font-size:2em;">' . $this->displayPrice($tr->total_pay, $currency) . '</span></td>
						</tr>
						<tr>
							<td>' . $this->l('Customer Fee Commission') . '</td>
							<td><span class="badge badge-warning">' . $this->displayPrice($tr->total_pay - $tr->total_cart, $currency) . '</span></td>
						</tr>
						<tr>
							<td>' . $this->l('POS System Fee') . '</td>
							<td><span class="badge badge-danger">' . $this->displayPrice($tr->gateway_fee, $currency) . '</span></td>
						</tr>
						<tr>
							<td>' . $this->l('E-Shop Remaining Amount') . '</td>
							<td><span class="badge badge-success" style="font-size:2em;">' . $this->displayPrice($tr->total_pay - $tr->gateway_fee, $currency) . '</span></td>
						</tr>
						<tr>
							<td colspan="2">
								' . $this->l('IP Address') . ' <span class="badge">' . $tr->cip . '</span>
								' . $this->l('Transaction number') . ' <span class="badge">' . $tr->boid . '</span>
							</td>
						</tr>
					</table>
					<div class="row align-center"><br/>
						<small>
							Bu bilgilerde bir hata olduğu düşünüyorsanız <a href="https://payu.com.tr/contact">Hata Bildirimi</a>
						</small>
					</div>
				</div>
			</div>
			<div class="col-md-6" >
				<div class="row">
					<div class="panel">
						<div class="panel-heading">
							<i class="icon-credit-card"></i>
							' . $this->l('Credit Card Info') . '
							<span class="badge">
								' . $tr->cc_name . '
							</span>
						</div>
						<table class="table">
							<tr>
								<td>' . $this->l('Card Type') . '</td>
								<td><img src="' . $this->uri . 'img/cards/' . ($tr->family != '' ? $tr->family : 'default') . '.png" /></td>
							</tr>
							<tr>
							<td>' . $this->l('Installment') . '</td>
							<td>' . $tr->installment . '</td>
							</tr>
							<tr>
								<td>' . $this->l('Card Name') . '</td>
								<td>' . $tr->cc_name . '</td>
							</tr>
							<tr>
								<td>' . $this->l('Card No') . '</td>
								<td>' . $tr->cc_number . '</td>
							</tr>
						</table>
					</div>
				</div>

			</div>
		</div>';
		$this->context .= $t;
		return $this->display();
	}

	public function displayCustomerOrder($tr)
	{
		$currency = new Currency($tr->id_currency);
		$t = '
		<div class="eticsoft">
			<div class="col-md-6" >
				<div class="panel">
					<div class="panel-heading">
						<i class="icon-credit-card"></i>
						' . $this->l('Credit Card Process Details') . '
						<span class="badge">
							' . $tr->gateway . '#' . $tr->boid . '
						</span>
					</div>
					<table class="table">
						<tr>
							<td>' . $this->l('POS answer:') . '#' . $tr->result_code . ' ' . $tr->result_message . '<br/>
								' . $this->l('Date') . ' <span class="badge">' . $tr->date_update . '</span></td>
							<td><img src="' . $this->url . '/img/gateways/' . $tr->gateway . '.png" /></td>
						</tr>
						<tr>
							<td>' . $this->l('Total Amount') . '</td>
							<td><span style="font-size:2em;">' . $this->displayPrice($tr->total_pay, $currency) . '</span></td>
						</tr>
						<tr>
							<td colspan="2">
								' . $this->l('IP Address') . ' <span class="badge">' . $tr->cip . '</span>
								' . $this->l('Transaction number') . ' <span class="badge">' . $tr->boid . '</span>
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div class="col-md-6" >
				<div class="row">
					<div class="panel">
						<div class="panel-heading">
							<i class="icon-credit-card"></i>
							' . $this->l('Credit Card Info') . '
							<span class="badge">
								' . $tr->cc_name . '
							</span>
						</div>
						<table class="table">
							<tr>
								<td>' . $this->l('Card Type') . '</td>
								<td><img src="' . $this->url . 'img/cards/' . ($tr->family != '' ? $tr->family : 'default') . '.png" /></td>
							<td>' . $this->l('Installment') . '</td>
							<td>' . $tr->installment . '</td>
							</tr>
							<tr>
								<td>' . $this->l('Card Name') . '</td>
								<td>' . $tr->cc_name . '</td>
								<td>' . $this->l('Card No') . '</td>
								<td>' . $tr->cc_number . '</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>';
		$this->context .= $t;
		return $this->display();
	}

	public function displayPdf($tr)
	{
		$currency = new Currency($tr->id_currency);
		$t = '
		<div class="eticsoft">
			<div class="col-md-6" >
				<div class="panel">
					<div class="panel-heading">
						<i class="icon-credit-card"></i>
						' . $this->l('Credit Card Process Details') . '
							' . $tr->gateway . '#' . $tr->boid . '
					</div>
					<table class="table">
						<tr>
							<td>' . $this->l('POS answer:') . '#' . $tr->result_code . ' ' . $tr->result_message . '<br/>
								' . $this->l('Date') . ' <span">' . $tr->date_update . '</span></td>
							<td>' . $tr->gateway . '</td>
						</tr>
						<tr>
							<td>' . $this->l('Total Amount') . '</td>
							<td><span>' . $this->displayPrice($tr->total_pay, $currency) . '</span></td>
						</tr>
						<tr>
							<td colspan="2">
								' . $this->l('IP Address') . ' <span">' . $tr->cip . '</span>
								' . $this->l('Transaction number') . ' <span>' . $tr->boid . '</span>
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div class="col-md-6" >
				<div class="row">
					<div class="panel">
						<div class="panel-heading">
							<i class="icon-credit-card"></i>
							' . $this->l('Credit Card Info') . '
								' . $tr->cc_name . '
						</div>
						<table class="table">
							<tr>
								<td>' . $this->l('Card Type') . '</td>
								<td>'.($tr->family != '' ? $tr->family : 'Credit/Debit').'</td>
							<td>' . $this->l('Installment') . '</td>
							<td>' . $tr->installment . '</td>
							</tr>
							<tr>
								<td>' . $this->l('Card Name') . '</td>
								<td>' . $tr->cc_name . '</td>
								<td>' . $this->l('Card No') . '</td>
								<td>' . $tr->cc_number . '</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>';
		$this->context .= $t;
		return $this->display();
	}

	public function displayProductInstallments($price)
	{
		$product = New Product(Etictools::getValue('id_product'));
		if (EticInstallment::getProductRestriction($product->id_category_default))
			return '<section><br/><div class="alert alert-info">Bu ürün kanun gereği taksitli olarak satılamamaktadır.'
				. ' Kredi kartınızdan taksitsiz olarak ödeyebilirsiniz.</div></section>';
		$prices = EticInstallment::getRates($price);
		if (count($prices) < 1)
			return;
		$return = '<div class="row">';
		$block_count = 0;
		foreach ($prices as $f => $v) {
			$block_count++;
			if ($block_count == 5) {
				$return .= '</div><div class="row">';
			}
			$return .= '<div class="col-lg-3 col-sm-6 col-xs-12 eticsoft_spr_bank">
				<div class="eticsoft_inst_container ' . $f . '">
					<div class="block_title"><img src="' . $this->uri . 'img/cards/' . $f . '.png"></div>';
			$return .= '<table class="table">
						<tr>
							<th>' . $this->l('Ins.') . '</th>
							<th>' . $this->l('Monthly') . '</th>
							<th>' . $this->l('Total') . '</th>
						</tr>';
			foreach ($v as $k => $ins) {
				$return .= '<tr class="' . ($k % 2 ? $f . '-odd' : '' ) . '">
				<td>' . $k . '</td>
				<td>' . EticTools::displayPrice($ins['month']) . '</td>
				<td>' . EticTools::displayPrice($ins['total']) . '</td>
			</tr>';
			}
			$return .= '</table></div></div>';
		}
		$return .= '<div class="col-lg-3 col-sm-6 col-xs-12 eticsoft_spr_bank">
				<div class="eticsoft_inst_container">
					<div class="block_title"><h3>' . $this->l('Other Cards') . '</h3></div>
					' . $this->l('You can pay ones way (without installment) via all visa/mastercard/amex credit cards, also debit cards') . '
					<hr/>
					<img class="col-sm-12 img-responsive" src="' . $this->uri . 'img/master_visa_aexpress.png"/>
					</div>
					</div>';
		$return .= '</div></section>';
		$this->context .= $return;
		return $this->display();
	}
}
