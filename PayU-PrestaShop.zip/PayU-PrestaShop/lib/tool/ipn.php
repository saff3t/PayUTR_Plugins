<?php

class EticSoft_Ipn {
	
	public static function savetoLog () {
		
	}
	
	public function run () {
		if(!EticTools::getValue('gateway') OR EticTools::getValue('gateway') != 'payu' OR !EticTools::getValue('REFNO'))
			return false;
		$gateway = New EticGateway(EticTools::getValue('gateway'));
		
		if(!$gateway->exists)
			return false;
		
		
		$lib_class_name = 'Eticsoft_' . $gateway->lib;
		$lib_class_path = dirname(__FILE__) . '/../../lib/gateways/' . $gateway->lib . '/' . $lib_class_name . '.php';
		$tr->debug("Try to include  " . $lib_class_name, true);
		$lib = New $lib_class_name();
		$tr = EticTransaction::getTransactionByBoId(EticTools::getValue('REFNO'));
		if(!$tr)
			return false;

		include_once($lib_class_path);

	}
	
}