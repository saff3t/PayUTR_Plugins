<?php
//	BU MOD�L �CRETSIZ DEGILDIR
//	DAGITIM VE KODLARDA DEGISIKLIK HAKKI SAKLIDIR
//	DEGISIKLIK HALINDE �ALISMA GARANTISI GE�ERSIZDIR
//	SADECE ETICSOFT TARAFINDAN DE���T�RLEB�L�R  

/*
 * 	T�rk bankalarina Uyumlu Sanal pos olarak �deme alir.
 * 	prestashopsanalpos.com (Prestashop Sanal Pos Projesi) Eticsoft Yazilim 2011
 * 	Daha Fazla bilgi almak i�i prestashopt-tr.com.com veya bilgi@prestashopt-tr.com.com
 *	(0 242) 241 59 85
 */

/*
 * 	Allows payment record via VPOS ordering for Turkish Banks API with a cradit card 
 * 	prestashopsanalpos.com Prestashop Development prestashopsanalpos.com Eticsoft Software inc 2011.
 * 	For more info and support prestashopsanalpos.com 
 *	+90.242 241 59 85 
 */

header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');

header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

header('Location: ../../../../');
exit;