<?php
include_once(dirname(__FILE__) . '/lib/class/inc.php');

class Payu extends PaymentModule
{

    private $_html = '';
    private $_gatewaytErrors = array();
    public $currencies, $bf, $path;
    public $requireCVC;

    function __construct()
    {
        $this->msg_errors = array();
        $this->msg_infos = array();
        $this->msg_warning = array();
        $this->sql = New EticSql();
        $this->name = 'payu';
        $this->displayName = 'Payu';
        $this->tab = 'payments_gateways';
        $this->version = 1.0;
        $this->author = "EticSoft R&D Lab Teknokent";
        $this->idOrderState = Eticconfig::get('POSPRO_IOS');
        if (!Eticconfig::get('POSPRO_CUR'))
            $this->_makeCurrencies();
        $this->currency = Eticconfig::get('POSPRO_CUR') ? Eticconfig::get('POSPRO_CUR') : null;
        $this->bootstrap = true;
        $this->is_eu_compatible = 1;
        parent::__construct();
        $this->dir = dirname(__FILE__);
        $this->uri = _MODULE_DIR_ . 'payu';
        $this->description = 'Payu üzerinden ödeme almanızı sağlar.';
        $this->path = $this->_path;
    }

    function install()
    {
        if (parent::install()) {
            if (
                    !$this->registerHook('payment')
                    OR ! $this->registerHook('payment')
                    OR ! $this->registerHook('paymentReturn')
                    OR ! $this->registerHook('adminOrder')
                    OR ! $this->registerHook('AdminCustomers')
                    OR ! $this->registerHook('productTabContent')
                    OR ! $this->registerHook('productTab')
                    OR ! $this->registerHook('productActions')
                    OR ! $this->registerHook('productfooter')
                    OR ! $this->registerHook('displayPDFInvoice')
                    OR ! $this->registerHook('displayCustomerAccount')
                    OR ! $this->registerHook('displayBackOfficeTop')
                    OR ! $this->registerHook('displayPayment')
                    OR ! $this->registerHook('displayPaymentReturn')
            ) {
                $this->_errors [] = 'Error while hook';
                return false;
            }
            if (version_compare(_PS_VERSION_, '1.7.0', '>=') === true) {
                $this->registerHook('paymentOptions');
            }
            $this->_makeCurrencies(); //Create Default Currencies
            $this->_makeOrderState(); //Create Credit Card Order State
            Eticconfig::set('POSPRO_API_DOMAIN', '');
            Eticconfig::set('POSPRO_API_EMAIL', '');
            Eticconfig::set('POSPRO_API_PUBLIC', '');
            Eticconfig::set('POSPRO_API_PRIVATE', '');
            Eticconfig::set('POSPRO_DEBUG_MOD', 'on');
            Eticconfig::set('POSPRO_TERMS', '');
            Eticconfig::set('POSPRO_SHOW_PRO_INST', 'on');
            Eticconfig::set('POSPRO_IOS', 2);
            Eticconfig::set('POSPRO_ORDER_AUTOFORM', 'on');
            Eticconfig::set('POSPRO_PRODUCT_TMP', 'color');
            Eticconfig::set('POSPRO_MAX_INSTALLMENTS', '9');
            Eticconfig::set('POSPRO_MIN_INST_AMOUNT', '1.00');
            Eticconfig::set('POSPRO_PAYMENT_PAGE', 'pro');
            Eticconfig::set('POSPRO_LATEST_VERSION', $this->version);
            Eticconfig::set('POSPRO_AUTO_CURRENCY', "on");
            Eticconfig::set('MASTERPASS_STAGE', "TEST");
            if (!Eticconfig::get('POSPRO_INSTALLED_VERSION'))
                Eticconfig::set('POSPRO_INSTALLED_VERSION', 4.7);
            if ((float) Eticconfig::get('POSPRO_INSTALLED_VERSION') < $this->version) {
                if (!$this->updatedatabase()) {
                    $this->_errors [] = 'Error while updating MYSQL table(s)';
                    return false;
                }
            }
            Eticconfig::set('POSPRO_INSTALLED_VERSION', $this->version);
            $query0 = "DROP TABLE IF EXISTS `" . _DB_PREFIX_ . "spr_installment` ";
            $query1 = "
			CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "spr_gateway` (
            `name` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
            `method` enum('cc', 'wire', 'other') NOT NULL,
            `full_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
            `lib` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
            `active` tinyint(1) NOT NULL DEFAULT '1',
            `params` text COLLATE utf8_unicode_ci NOT NULL,
            UNIQUE KEY (`name`)
          ) DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

      INSERT INTO `" . _DB_PREFIX_ . "spr_gateway`
            (`name`, `method`, `full_name`, `lib`, `active`, `params`)
      VALUES
            ('payu','cc','PayU Türkiye','payu', 1, '');";

            $query2 = "
			CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "spr_installment` (
            `gateway` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
            `family` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
            `divisor` int(3) NOT NULL,
            `rate` decimal(4,2) NOT NULL,
            `fee` decimal(4,2) NOT NULL DEFAULT '0.00',
            UNIQUE KEY `gateway` (`family`,`divisor`)
          ) DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

      INSERT INTO `" . _DB_PREFIX_ . "spr_installment`
            (`gateway`, `family`, `divisor`, `rate`, `fee`)
      VALUES
            ('payu','all',1,0,0);";


            $query3 = "
			CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "spr_transaction` (
			  `id_transaction` int(11) NOT NULL AUTO_INCREMENT,
			  `notify` tinyint(1) NOT NULL DEFAULT '0',
			  `cc_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
			  `cc_number` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
			  `gateway` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
			  `family` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
			  `id_cart` int(11) NOT NULL,
			  `id_currency` int(11) NOT NULL,
			  `id_order` int(11) DEFAULT NULL,
			  `id_customer` int(11) NOT NULL,
			  `total_cart` float(10,2) DEFAULT NULL,
			  `total_pay` float(10,2) DEFAULT NULL,
			  `gateway_fee` float(10,2) DEFAULT NULL,
			  `installment` int(2) NULL,
			  `cip` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
			  `test_mode` int(1) NOT NULL,
			  `tds` int(1) NOT NULL,
			  `boid` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
			  `result_code` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL,
			  `result_message` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
			  `result` int(1) NOT NULL,
			  `detail` TEXT DEFAULT NULL,
			  `date_create` datetime NOT NULL,
			  `date_update` datetime DEFAULT NULL,
			  PRIMARY KEY (`id_transaction`)
			) DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"
            ;

            $query4 = "
			CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "spr_debug` (
			  `id_transaction` int(11) NOT NULL,
			  `debug` text NULL,
			  UNIQUE KEY `id_transaction` (`id_transaction`)
			) DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";

            EticSql::execute("DROP TABLE IF EXISTS `" . _DB_PREFIX_ . "spr_debug` ");

            if (!EticSql::execute($query0)
                    OR ! EticSql::execute($query1)
                    OR ! EticSql::execute($query2)
                    OR ! EticSql::execute($query3)
                    OR ! EticSql::execute($query4)
            ) {
                $this->_errors [] = 'Error while creating MYSQL table(s)' ;
                return false;
            }
            Eticconfig::set('POSPRO_INSTALLED_VERSION', $this->version);
            if (count(EticGateway::getGateways()) < 1) {
                $gateway = New EticGateway('eticpos');
                $gateway->add();
            }
        }
        EticGateway::add();
        return true;
    }

    function updatedatabase()
    {
        EticSql::execute("DROP TABLE IF EXISTS `" . _DB_PREFIX_ . "spr_installment` ");
        EticSql::execute("DROP TABLE IF EXISTS `" . _DB_PREFIX_ . "spr_debug` ");
		return true;
    }

    function uninstall()
    {
        parent::uninstall();
        return true;
    }

    function getContent()
    {
        $error_message = false;
                $this->_html = '
			<div class="row panel">
				<div class="col-sm-6 col-xs-6">
					<a target="_blank;" href="https://payu.com.tr">
                    <img src="../modules/payu/img/gateways/payu.png" />
                    </a>
					Versiyon<span style="font-size:1.5em;">v' . ((float) $this->version ) . '</span> '
                . '
				</div>

			</div>
		';  //Display Header
		if (Etictools::getValue('spr_terms')) {
			if(!EticTools::isMobile(EticTools::getValue('spr_shop_phone'))){
				$this->context->smarty->assign(array(
				'error_message' =>
				'Girdiğiniz cep telefonu ('.EticTools::getValue('spr_shop_phone').') doğru değil ! Doğru örnek 0505XXXYYZZ.
				<br/> Not:<b> Cep telefonu numaranız kesinlikle spam/rahatsız edici sms amacıyla kullanılmayacaktır </b> '));
				return $this->_html . $this->context->smarty->fetch($this->local_path . 'views/templates/admin/terms.tpl');

			}

            $spapi = New SanalPosApiClient(0);
            $data = $spapi->getRegisterVariables();
            $request = Etictools::curlPostExt(
                            array('data' => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)), $spapi->getLoginFormValues()['url'] . 'register.php', false);
            if (!$result = json_decode(Etictools::removeBOM($request)))
                $error_message = 'Veri alışverişi sırasında hata oldu. Lütfen Tekrar Deneyin veya EticSoft ile görüşünüz'
                        . '<small>(' . $request . ')</small>';
            else if ($result->result) {
                EticConfig::set('POSPRO_TERMS', true);
                EticConfig::set('POSPRO_API_PUBLIC', $result->public);
                EticConfig::set('POSPRO_API_PRIVATE', $result->private);
                EticConfig::set('POSPRO_API_DOMAIN', $result->domain);
                EticConfig::set('POSPRO_API_EMAIL', $data['email']);
            } else
                $error_message = $result->result_message;
        }
        if (!EticConfig::get('POSPRO_API_PUBLIC') OR ! EticConfig::get('POSPRO_TERMS')) {
            $this->context->smarty->assign(array('error_message' => $error_message));
            return $this->_html . $this->context->smarty->fetch($this->local_path . 'views/templates/admin/terms.tpl');
        }
        $definitions = $this->sppGetStoreMethods();

        if ($definitions->result != 1 OR $definitions->result_message != 'success') {
            return $this->_html . EticConfig::displayError($definitions->result_message, 'Hata '.$definitions->result_code);
        }
        EticGateway::$gateways = $definitions->data->gateways;
        EticGateway::$api_libs = $definitions->data->api_libs;
        $this->context->controller->addCSS($this->_path . '/views/css/admin.css');
        $this->context->controller->addJs($this->_path . '/views/js/admin.js');
        $this->sppSaveSettings();

        $this->_displayForm();
        return $this->_html;
    }

    private function _displayForm()
    {
        $api_libs = EticGateway::$api_libs;
        EticConfig::getConfigNotifications();
        $this->context->smarty->assign(array(
            'viewlog' => (Etictools::getValue('id_transaction') ? $this->getDebug(Etictools::getValue('id_transaction')) : false),
            'general_tab' => EticConfig::getAdminGeneralSettingsForm($this->_path),
            'banks_tab' => EticConfig::getAdminGatewaySettingsForm($this->_path),
            'integration_tab' => EticConfig::getAdminIntegrationForm($this->_path),
            'cards_tab' => EticConfig::getCardSettingsForm($this->_path),
            'tools_tab' => EticConfig::getAdminToolsForm($this->_path),
            'help_tab' => EticConfig::getHelpForm($this->_path),
            'masterpass_tab' => EticConfig::getMasterPassForm($this->_path),
            'last_records' => $this->getLastRecordsTable(),
            'stats_gateways' => EticStats::getChart('getGwUsagebyTotal'),
            'stats_monthly' => EticStats::getChart('getMontlyIncome'),
            'module_dir' => $this->_path,
            'messages' => EticConfig::$messages,
            'key' => EticTools::GenerateKey($this->id),
        ));
        $this->_html .= $this->context->smarty->fetch($this->local_path . 'views/templates/admin/admin.tpl');
		return 1;
    }

    private function getLastRecordsTable()
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'spr_transaction ORDER BY `date_create` DESC LIMIT 40 ';
        $result = Db::getInstance()->ExecuteS($sql);
        $fields_list = array(
            'id_transaction' => array(
                'title' => $this->l('Id'),
                'width' => 40,
                'type' => 'text',
            ),
            'date_create' => array(
                'title' => $this->l('Date'),
                'width' => 140,
                'type' => 'datetime',
            ),
            'total_pay' => array(
                'title' => $this->l('Amount'),
                'width' => 40,
                'type' => 'price',
            ),
            'installment' => array(
                'title' => $this->l('Inst.'),
                'width' => 40,
                'type' => 'int',
            ),
            'gateway' => array(
                'title' => $this->l('Gateway'),
                'width' => 60,
                'type' => 'text',
                'callback' => "getGatewayName",
                'callback_object' => new Etictools(),
            ),
            'gateway' => array(
                'title' => $this->l('Gateway'),
                'width' => 60,
                'type' => 'text',
            ),
            'result' => array(
                'title' => $this->l('Result'),
                'width' => 140,
                'type' => 'bool',
                "icon" => array(0 => "disabled.gif", 1 => 'enabled.gif',),
                "default" => "disabled.gif",
            ),
            'cc_number' => array(
                'title' => $this->l('Credit Card Number'),
                'width' => 140,
                'type' => 'text',
            ),
            'cip' => array(
                'title' => $this->l('IP Addr'),
                'width' => 60,
                'type' => 'text',
            ),
            'boid' => array(
                'title' => $this->l('Gateway Proc No'),
                'width' => 60,
                'type' => 'text',
            ),
            'id_customer' => array(
                'title' => $this->l('Customer'),
                'width' => 120,
                'type' => 'text',
                'callback' => "getCustomerName",
                'callback_object' => new Etictools(),
            ),
        );
        $helper = new HelperListCore();
        $helper->shopLinkType = '';
        $helper->simple_header = true;
        // Actions to be displayed in the "Actions" column
        //  $helper->actions = array('edit', 'delete', 'view');
        $helper->identifier = 'id_transaction';
        $helper->show_toolbar = true;
        $helper->title = 'Son 40 işlem';
        $helper->table = 'spr_transaction';
        $helper->table_id = 'spr_transaction';
        // $helper->actions = array('view');
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        return $helper->generateList($result, $fields_list);
    }

    /**
     * 	_displayForm()
     * 	Called in Back Office during Module Configuration
     */
    // FORM GET AND UPDATE/INSERT DB
    function sppSaveSettings()
    {
        if (EticTools::getValue('add_new_pos')) {
            $gateway = New EticGateway(EticTools::getValue('add_new_pos'));
            $gateway->add();
        }
        if (Etictools::getValue('savetoolsform') OR Etictools::getValue('check-oldtables')) {
            EticConfig::saveToolsForm();
        }
        if (Etictools::getValue('submitcardrates')) {
            EticConfig::saveCardSettingsForm();
        }
        if (Etictools::getValue('submitgwsetting')) {
            EticConfig::saveGatewaySettings();
        }
        if (EticTools::getValue('conf-form') && EticTools::getValue('conf-form') == 1) {
            EticConfig::saveGeneralSettings();
            EticTools::rwm('Genel Ayarlar Güncellendi', true, 'success');
        }
    }

    public function getDebug($id_transaction)
    {
        $tra = New EticTransaction($id_transaction);
        return $tra->getDebug();
    }

    /**
     * 	hookPayment($params)
     * 	Called in Front Office at Payment Screen
     */
    function hookPayment()
    {
        global $smarty;
        $shop = Context::getContext()->shop;
        $smarty->assign(array(
            'this_path' => $this->_path,
            'this_path_ssl' => 'https://' . $shop->domain_ssl . $shop->getBaseURI() . "modules/{$this->name}/"));
        return $this->display(__FILE__, 'payment.tpl');
    }

    /**
     * 	hookAdminOrder($params)
     * 	Called in Back Office upon Order Review
     * 	Note: Only return data if an order is a Credit Card order.
     */
    function hookAdminOrder($params)
    {
        if (!$tra = EticSql::getRow('spr_transaction', 'id_order', $params['id_order']))
            return false;
        $tr = New EticTransaction($tra['id_transaction']);
		$ui = New EticUiPrestashop($this);
		return $ui->displayAdminOrder($tr);
        global $smarty;
        $smarty->assign(array(
            'tr' => $tr
        ));
        return $this->display(__FILE__, 'invoice_block.tpl');
    }

    /*
     * 1.7
     */

    public function hookPaymentOptions($params)
    {
        if (version_compare(_PS_VERSION_, '1.7.0', '>=') != true)
            return $this->hookPayment();
        if (!$this->active) {
            return;
        }
		$payment_options = array();
        $newOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption;
        $newOption->setModuleName($this->name)
                ->setCallToActionText($this->trans('', array(), 'Modules.Payu.Shop'))
                ->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true))
                ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/img/payu-kredi-karti.png'))
                ->setAdditionalInformation($this->trans('Tüm kredi kartları ile güvenli alışveriş', array(), 'Modules.Payu.Shop'));
        $payment_options[] = $newOption;
        return $payment_options;
    }

    function hookAdminCustomers($params)
    {
        return '';
    }

    function hookDisplayPDFInvoice($params)
    {
		if(EticConfig::get('POSPRO_HOOK_PDF') == 'off')
			return;
		if(isset($params['object']))
			$id_order = $params['object']->id_order;
		else if(isset($params['objOrder']))
			$id_order = $params['objOrder']->id;

		if(!isset($id_order) OR !$id_order) {
            return false;
		}
        if (!$order_record = EticSql::getRow('spr_transaction', array('id_order' => $id_order, 'result' => true)))
            return false;
		$tr = New EticTransaction($order_record['id_transaction']);
		$ui = New EticUiPrestashop();
		return $ui->displayPdf($tr);
    }

    /**
     * 	hookPaymentReturn($params)
     * 	Called in Front Office upon order placement
     */
    function hookPaymentReturn($params)
    {
        return $this->hookDisplayPDFInvoice($params);
    }

    /**
     * 	makeCurrencies()
     * 	Called from within creditcard.php if no default currencies exist
     */
    public function _makeCurrencies()
    {
        if (Currency::getIdByIsoCode("TRY"))
            return Eticconfig::set('POSPRO_CUR', Currency::getIdByIsoCode("TRY"));
    }

    /**
     * 	makeOrderState()
     * 	An order state is necessary for this module to function.
     * 	The id number of the order state is stored in a global configuration variable for use later
     */
    private function _makeOrderState()
    {
        Eticconfig::set('POSPRO_IOS', 2);
    }

    public function hookproductfooter()
    {
        if (Eticconfig::get('POSPRO_TAKSIT_GOSTER') == "off")
            return "-";
		$ui = New EticUiPrestashop($this);
		$ui->addCSS('views/css/installments-' . Eticconfig::get('POSPRO_PRODUCT_TMP') . '.css');
		$ui->addCSS('views/css/installments.css');
        return $ui->displayProductInstallments(Product::getPriceStatic(EticTools::getValue('id_product')));
    }

    public function hookdisplayCustomerAccount()
    {
        return '';
    }

    public function hookdisplayBackOfficeTop($params)
    {
        return;
    }

    // function post2Gateway($tr = false)
    // {
    //     if ($tr == false)
    //         $tr = EticTransaction::createTransaction();
    //     $gateway = New EticGateway($tr->gateway);
    //     $lib_class_name = 'Eticsoft_' . $gateway->lib;
    //     $lib_class_path = dirname(__FILE__) . '/lib/gateways/' . $gateway->lib . '/' . $lib_class_name . '.php';
    //     $tr->debug("Try to include Gateway of " . $lib_class_path);
    //     include_once($lib_class_path);
    //     $lib = New $lib_class_name($tr);
    //     return $lib->post2Bank($tr);
    // }

    private function sppGetStoreMethods()
    {
        $cli = New SanalPosApiClient(1, 'UNKNOWN', 'getstoregateways2');
        return $cli->validateRequest()->run()->getResponse();
    }

    public function hookDisplayPayment($params)
    {
        return $this->hookPaymentOptions($params);
    }

    public function hookDisplayPaymentReturn($params)
    {
        return $this->hookPaymentReturn($params);
    }

    function checkUpdates()
    {
        return;
    }

    /*
      deprecated
     */

    public function hookproductTabContent($params)
    {
		$this->hookproductfooter($params);
    }

    /*
      deprecated
     */

    public function hookProductTab()
    {
        return "";
    }

    public function hookProductActions()
    {
        return "";
    }

}
